//
//  land.cpp
//  temp
//
//  Created by Kerwin_You on 15/12/13.
//  Copyright © 2015年 ___Kerwin___. All rights reserved.
//

#include "../include/land.hpp"

/**
*获取降落所有基准图Hu值,abs(log(abs(variable)))
**/
void getLandBase(double hu[])
{
    ofstream fileTest("/home/ubuntu/catkin_ws/src/dji_ros/Onboard-SDK-ROS/uva_visual_guidence/flyData/hu.txt");
    char ln[80];
    FILE *f;
    int i,n;
    f=fopen("/home/ubuntu/catkin_ws/src/dji_ros/Onboard-SDK-ROS/uva_visual_guidence/land_base.txt","r");
    if (NULL==f)
    {
        fileTest<<"Can not open file Data.txt!\n"<<endl;
        printf("Can not open file Data.txt!\n");
        return ;
    }
    i=0;
    while (1)
    {
        if (NULL==fgets(ln,80,f))
        {
            break;
        }
        sscanf(ln, "%lf", &hu[i]);
        cout<<"hu: "<<hu[i]<<endl;
        fileTest<<"hu: "<<hu[i]<<endl;
        i++;
    }
    fclose(f);
}

/*
*降落函数，由当前图获取无人机偏移
*Param:
*Mat: 当前图
*float: 当前高度
*double:基准降落标志的hu矩
*ofstream: 记录降落日志
*Return:
*计算得到的降落偏移量
*/

struct LandData land(Mat image,float height,double hu[],ofstream& fileLand)
{
//    ofstream fileTest("/home/ubuntu/catkin_ws/src/dji_ros/Onboard-SDK-ROS/uva_visual_guidence/flyData/land.txt");
    struct LandData landData;
    landData.delta.x=0;
    landData.delta.y=0;
    landData.coefficient=0;
    int cmin=0, cmax=0;
//不同高度下过滤轮廓长度的阈值
    if(abs(height-100)<2)
    {
        cmin=30;
        cmax=80;
        landData.coefficient=0.1515;
    }
    else if(abs(height-50)<2)
    {
        cmin=90;
        cmax=160;
        landData.coefficient=0.0704;
    }
    else if(abs(height-20)<2)
    {
        cmin=260;
        cmax=450;
        landData.coefficient=0.0255;
    }
    else
    {
        return landData;
    }
    Point center,centerNext,delta;//center为H在图片坐标，delta为机体坐标系下飞机需要的偏移
//阀值的选取与天气有关，晴天180左右，阴天100左右
//    vector<vector<Point>> contours_base=drawCourters(image_base,100,128, 480);
//    //50米，size=170、147;45米,size=147、193;55米，size=155、132;
    //20米，size=436、402;25米,size=361、314
    //100米，size=79、72;95米,size=75、83

    vector<vector<Point>> contours=drawCourters(image,120,cmin,cmax);//565编号图片标准值146;640编号图片标准值76；
    for(int i=0; i<contours.size(); i++)
    {
        //计算当前轮廓中心点
        for(int j=0; j<contours[i].size(); j++)
            {
                center+=contours[i][j];
            }
        center.x/=contours[i].size();
        center.y/=contours[i].size();
        fileLand<<"center: "<<center.x<<": "<<center.y<<endl;
        center.x=center.y=0;
        //计算当前轮廓hu
        if(huMoment_calculate(contours[i],hu,fileLand)==true)
        {
            for(int j=0; j<contours[i].size(); j++)
            {
                center+=contours[i][j];
            }
            center.x/=contours[i].size();
            center.y/=contours[i].size();
            //严格来说需要判断此时数组会不会溢出
            if(i==(contours.size()-1)){
                break;
            }
            //计算下一轮阔的长度
            for(int j=0; j<contours[i+1].size(); j++)
            {
                centerNext+=contours[i+1][j];
            }
            centerNext.x/=contours[i+1].size();
            centerNext.y/=contours[i+1].size();
            fileLand<<"center: "<<center.x<<": "<<center.y<<endl;
            fileLand<<"centerNext: "<<centerNext.x<<": "<<centerNext.y<<endl;
//            cout<<"temp data: "<<(centerNext.x/=contours[i+1].size())<<": "<<(centerNext.y/=contours[i+1].size())<<endl;
            //如果下一轮廓中心点和当前轮廓中心点不相近
            if(abs(centerNext.x-center.x)>15||abs(centerNext.y-center.y)>15)
            {
//                fileLand<<"centerNext: "<<centerNext.x<<": "<<centerNext.y<<endl;
                continue;
            }
            landData.delta.x=720/2-center.y;
            landData.delta.y=center.x-1280/2;
            fileLand<<"contour: "<<i<<"th"<<endl;//(从0开始编号)
            fileLand<<"center.x: "<<center.x<<"center.y"<<center.y<<"delta.x: "<<landData.delta.x<<"delta.y"<<landData.delta.y<<endl;
            return landData;
        }
    }
    return landData;
}

//int main()
//{
//    Mat image=imread("/home/ubuntu/catkin_ws/src/dji_ros/Onboard-SDK-ROS/uva_visual_guidence/images/2199.jpg",0);
//    land(image,130,160);
//    return 0;
//}
