//
//  HuMoment_calculate.cpp
//  temp
//
//  Created by Kerwin_You on 15/12/16.
//  Copyright © 2015年 ___Kerwin___. All rights reserved.
//

#include "../include/HuMoment_calculate.hpp"
#include "../include/drawCourters.hpp"

/*
 *计算当前边缘和预定降落图的hu
 */
bool huMoment_calculate(vector<Point> contours,double hu1[7],ofstream& fileLand)
{
    Moments mts = moments(contours);
    double hu[7];
    HuMoments(mts, hu);
//    for (int i=0; i<7; i++)
//    {
//        fileTest<<"hu1: "<<hu1[i]<<endl;
//    }
//    for (int i=0; i<7; i++)
//    {
//        cout <<"H: "<< log(abs(hu[i])) <<endl;
//    }
//    for (int i=0; i<7; i++)
//    {
//        cout << "H_1: "<<log(abs(hu1[i])) <<endl;
//    }
    double dbR =0; //相似度，可以尝试其他方法
    double dSigmaST =0;
    double dSigmaS =0;
    double dSigmaT =0;
    double temp =0;
    for(int i=0; i<7; i++)
    {
        dSigmaST+=fabs(hu[i]*hu1[i]);
        dSigmaS+=pow(hu[i],2);
        dSigmaT+=pow(hu1[i],2);
    }
//    cout<<"Hu abs"<<abs(abs(log(abs(hu[0])))-abs(log(abs(hu1[0]))))<<endl;
    float dis0=abs(abs(log(abs(hu[0])))-abs(log(abs(hu1[0]))));
    float dis1=abs(abs(log(abs(hu[1])))-abs(log(abs(hu1[1]))));
    fileLand<<"HU0: "<<dis0<<endl;
    fileLand<<"HU1: "<<dis1<<endl;
    //当前图和基准图之间的阈值变动
    if(dis0<0.1&&dis1<0.6)
    {
        dbR = (double)(dSigmaST/(sqrt(dSigmaS)*sqrt(dSigmaT)));
        cout<<"similarity: "<<dbR<<endl;
        if(dbR<0.999)
        {
            return false;
        }
        return true;
    }
    else
    {
        return false;
    }
}
