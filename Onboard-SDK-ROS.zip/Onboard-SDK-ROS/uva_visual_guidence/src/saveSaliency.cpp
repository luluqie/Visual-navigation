﻿//
//  testSaliency.cpp
//  UVA
//
//  Created by Kerwin_You on 16/1/12.
//  Copyright © 2016年 ___Kerwin___. All rights reserved.
//

#include "../include/saveSaliency.h"

using namespace std;

int SaveSaliency(string InputPath, string SavePath)
{
	const char* inPath = InputPath.c_str();
	const char* saPath = SavePath.c_str();
	Saliency sal;
	vector<double> salmap(0);
	IplImage* img = cvLoadImage(inPath);//读取待处理图像
	if (!img) {
		cout << "failed to load image" << endl;
	}

	assert(img->nChannels == 3);
	vector<unsigned int >imgInput;
	vector<double> imgSal;
	//IplImage to vector
	for (int h = 0; h<img->height; h++) {
		unsigned char*p = (unsigned char*)img->imageData + h*img->widthStep;
		for (int w = 0; w<img->width; w++) {
			unsigned int t = 0;
			t += *p++;
			t <<= 8;
			t += *p++;
			t <<= 8;
			t += *p++;
			imgInput.push_back(t);
		}
	}
	sal.GetSaliencyMap(imgInput, img->width, img->height, imgSal);
	//vector to IplImage
	int index = 0;
	IplImage* imgout = cvCreateImage(cvGetSize(img), IPL_DEPTH_64F, 1);
	for (int h = 0; h<imgout->height; h++) {
		double*p = (double*)(imgout->imageData + h*imgout->widthStep);
		for (int w = 0; w<imgout->width; w++) {
			*p++ = imgSal[index++];
		}
	}

	cvSaveImage(saPath, imgout);
	cvReleaseImage(&img);
	cvReleaseImage(&imgout);

	return 0;
}
