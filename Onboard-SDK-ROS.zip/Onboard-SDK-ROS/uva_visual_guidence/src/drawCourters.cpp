//
//  drawCourters.cpp
//  temp
//
//  Created by Kerwin_You on 15/12/16.
//  Copyright © 2015年 ___Kerwin___. All rights reserved.
//

#include "../include/drawCourters.hpp"
/*
 *获取指定范围内的边缘
 *image：图像的矩阵
 *thresh：二值化处理的阀值
 *cmin：边缘点最小值
 *cmax：边缘点最大值
 *return: 返回保留的边缘
 */
vector<vector<Point>> drawCourters(Mat image,int thresh,int cmin,int cmax)
{
    ofstream fileTest("/home/ubuntu/catkin_ws/src/dji_ros/Onboard-SDK-ROS/uva_visual_guidence/flyData/contours.txt");

//    imshow("temp", image);
//    waitKey();
    threshold(image,image,thresh,255,CV_THRESH_BINARY);
    imwrite("/home/ubuntu/catkin_ws/src/dji_ros/Onboard-SDK-ROS/uva_visual_guidence/flyData/threshold.jpg", image);
//    waitKey();
    // Get the contours of the connected components
    vector<vector<Point>> contours;
    //findContours的输入是二值图像
    findContours(image,
                 contours, // a vector of contours
                 CV_RETR_LIST, // retrieve the external contours
                 CV_CHAIN_APPROX_NONE); // retrieve all pixels of each contours

    // draw black contours on white image
    Mat result(image.size(),CV_8U,Scalar(0));
    //    drawContours(result,contours,      //画出轮廓
    //                 0,Scalar(255), // in black
    //                 2); // with a thickness of 2
    //
    //    namedWindow("Contours");
    //    imshow("Contours",result);
    //    waitKey();
    // Eliminate too short or too long contours

    vector<vector<Point>>::iterator itc= contours.begin();
    while (itc!=contours.end())
    {

        if (itc->size() < cmin || itc->size() >cmax)
            itc= contours.erase(itc);
        else
            ++itc;
    }

    for(int i=0; i<contours.size(); i++)
    {
        drawContours(result,contours,      //画出轮廓
                     i, // draw all contours
                     Scalar(255), // in black
                     2); // with a thickness of 2
//        cout<<"size: "<<contours[i].size()<<endl;
        fileTest<<"size: "<<contours[i].size()<<endl;
//        namedWindow("extracted", CV_WINDOW_AUTOSIZE);
//        imshow("extracted",result);
//        waitKey();
    }
    fileTest.close();
    return contours;
}
