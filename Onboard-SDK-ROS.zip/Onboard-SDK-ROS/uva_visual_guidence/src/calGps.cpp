#include "../include/calGps.hpp"

/*
function:
由坐标计算gps
parameter:
coordinate:坐标
return:
gps:gps值
*/

const double GPSPERX=0.000007369;  //每个横坐标像素代表的gps
const double  GPSPERY=0.000006175;  //每个纵坐标像素代表的gps
const double  GPSY=30.755919;   //基准图左上角的GPSX值
const double  GPSX=103.920422;   //基准图左上角的GPSY值
Point2f calGpsFromCoor(Point2f coordinate)
{
    Point2f gps;
    gps.x=GPSX+coordinate.x*GPSPERX;//代表经度
    cout.precision(6);
    gps.y=GPSY-coordinate.y*GPSPERY;//代表纬度
    return gps;
}

Point2f calCoorFromGps(Point2f gps){
    Point2f coordinate;
    coordinate.x=(gps.x-GPSX)/GPSPERX;
    coordinate.y=(GPSY-gps.y)/GPSPERY;
    return coordinate;
}

//int main()
//{
//    Point2f coordinates;
//    Point2f gps;
//    gps.x=103.927095;
//    gps.y=30.751876;
//    coordinates=calCoorFromGps(gps);
//    cout<<coordinates.x<<" : "<<coordinates.y<<endl;
//    return 0;
//}
//
