#include "../include/calMatchCoordinate.hpp"

/*
*function:
*匹配成功后，由匹配区域中心点坐标换算到当前图中心点坐标，（坐标轴为OpenCV自带坐标轴）
*parameter:
*coordinates: coordinates[0]存放匹配区域中心点坐标,coordinates[1]存放显著性区域匹配中心点坐标（即基准图坐标轴坐标）
*yaw：飞控获取的当前无人机偏角
*return:
*coordinate:计算得到的无人机在基准图坐标
*/

Point2f calMatchCoordinate(vector<Point2f> coordinates, float yaw)
{
    Point2f gps;
    Point2f coordinate;
    double distance=0;//匹配中心点和当前图像中心点的距离
    double theta=0;//匹配中心点和当前图中心点在右手坐标系中的夹角
    yaw=yaw/180*M_PI;
//    cout<<"yaw: "<<yaw<<endl;
    distance=sqrt(pow(coordinates[0].x-CENTERX,2)+pow(coordinates[0].y-CENTERY,2));
//    cout<<"distance: "<<distance<<endl;
    coordinates[0].x=coordinates[0].x-CENTERX;//坐标换算到弧度制坐标系下
    coordinates[0].y=CENTERY-coordinates[0].y;
//    cout<<"original : "<<coordinates[0]<<endl;
    theta=atan(coordinates[0].y/coordinates[0].x);
    if(coordinates[0].y>=0)
    {

        if(theta<0)
        {
            theta+=M_PI;//换算到弧度制坐标系下再求
        }
    }
    else
    {
        if(theta<0)
        {
            theta+=2*M_PI;//换算到弧度制坐标系下再求
        }
        else
        {
            theta+=M_PI;
        }
    }
//    cout<<"theta: "<<theta/M_PI*180<<endl<<"cos "<<cos(theta)<<endl<<"sin :"<<sin(theta)<<endl;
    {
        coordinate.x=coordinates[1].x-distance*cos(theta-yaw);
        coordinate.y=coordinates[1].y+distance*sin(theta-yaw);
    }
//    cout<<"coordiante image coor: "<<coordinate.x<<" "<<coordinate.y<<endl;
    return coordinate;
}
