#include "../include/klt.hpp"

/*
Mat klt(Mat& imgA, Mat& imgB,Size viewSize)
输入：Mat imgA   前一张图片(灰度图)
输入：Mat imgB   当前图片(灰度图)
输入：double ratio  视野范围对应的实际尺度
返回：Point shift   像素级别的平移向量
*/
Point2f klt(Mat imgA, Mat imgB, double sizeRatio)
{
    const int MAX_CORNERS = 500;//角点数上线
    Mat eig_img;

    Point2f shift = Point2f(0, 0);//无人机平移的距离向量

    Size smallSize;
    smallSize.height = 0;
    smallSize.width = 0;

    resize(imgA, imgA, smallSize, sizeRatio, sizeRatio);
    resize(imgB, imgB, smallSize, sizeRatio, sizeRatio);
    Mat imgC = imgB;
    vector<Point2f> cornersA, cornersB;
    vector<uchar> features_found;
    vector<float> feature_errors;
    Size win_size = Size(10, 10);
    Size zeroZone = Size(-1, -1);
    vector<Point> vectorLine;


    goodFeaturesToTrack(imgA, cornersA, MAX_CORNERS, 0.01, 5.0, eig_img, 3, true, 0.04);

    TermCriteria criteria = TermCriteria(CV_TERMCRIT_EPS + CV_TERMCRIT_ITER, 40, 0.01);

    cornerSubPix(imgA, cornersA, win_size, zeroZone, criteria);

    calcOpticalFlowPyrLK(imgA, imgB, cornersA, cornersB, features_found, feature_errors, win_size, 5, criteria, 0, 0.0001);
    vector<Point> p0Set, p1Set;
    for (size_t i = 0; i < cornersA.size(); i++)
    {
        Point p0, p1;
        p0 = Point(round(cornersA[i].x), round(cornersA[i].y));
        p1 = Point(round(cornersB[i].x), round(cornersB[i].y));
        p0Set.push_back(p0);
        p1Set.push_back(p1);
        vectorLine.push_back(Point(p0.x - p1.x, p1.y - p0.y));
    }

    int count = 1;
    float xSum, ySum;
    xSum = 0;
    ySum = 0;
    for (size_t i = 0; i < vectorLine.size(); i++)
    {
        xSum += vectorLine[i].x;
        ySum += vectorLine[i].y;
        count++;
    }

    float xShift, yShift;
    xShift = xSum / count;
    yShift = ySum / count;

    count = 1;
    xSum = 0;
    ySum = 0;

    Point tmp1, tmp2;
    bool flag;
    float ratio = 1.5;
    for (size_t i = 0; i != vectorLine.size(); ++i)
    {
        //判断当前无人机移动方向
        if (xShift > 0)
        {
            if (yShift > 0)
                flag = vectorLine[i].y > ratio * yShift || vectorLine[i].x > ratio * xShift || vectorLine[i].y < 0 || vectorLine[i].x < 0;
            else
                flag = vectorLine[i].y < ratio * yShift || vectorLine[i].x > ratio * xShift || vectorLine[i].y > 0 || vectorLine[i].x < 0;
        }
        else
        {
            if (yShift > 0)
                flag = vectorLine[i].y > ratio * yShift || vectorLine[i].x < ratio * xShift || vectorLine[i].y < 0 || vectorLine[i].x > 0;
            else
                flag = vectorLine[i].y < ratio * yShift || vectorLine[i].x < ratio * xShift || vectorLine[i].y > 0 || vectorLine[i].x > 0;
        }
        if (flag)
        {
            p0Set[i].x = 10;
            p0Set[i].y = 10;
            p1Set[i].x = 10;
            p1Set[i].y = 10;
        }
        else
        {
            tmp1.x = p0Set[i].x;
            tmp1.y = p0Set[i].y;
            tmp2.x = p1Set[i].x;
            tmp2.y = p1Set[i].y;

            ++count;
            xSum += tmp1.x - tmp2.x;
            ySum += tmp2.y - tmp1.y;
            line(imgC, tmp1, tmp2, Scalar(255, 0, 0), 2);
        }
    }
    if(count>=5)
    {
        xShift = (float)xSum / count;
        yShift = (float)ySum / count;

        shift.x = xShift;//无人机横向平移的距离
        shift.y = -yShift;//无人机纵向平移的距离
    }
    else
    {
        shift.x=shift.y=0;
    }
    return shift; //return imgC;
}

/*
*将klt追踪结果根据夹角映射到大地坐标系
*Param:
*Point2f:输入的klt结果
*float: 图片采集时的夹角
*Return:
*大地坐标系下的klt值
*/
Point2f changeAxes(Point2f result0,float useYaw)
{
    float kltDis=sqrt(pow(result0.x,2)+pow(result0.y,2));
    double theta=0;
    //计算偏移向量在图片坐标系的夹角
    if(result0.y==0&&result0.x>0)
    {
        theta=0;
    }
    else if(result0.y==0&&result0.x<0)
    {
        theta=M_PI;
    }
    else if(result0.x==0&&result0.y>0)
    {
        theta=M_PI/2;
    }
    else if(result0.x==0&&result0.y<0)
    {
        theta=3*M_PI/2;
    }
    else if(result0.y>0&&result0.x!=0)
    {
        theta=atan(result0.y/result0.x);
        if(theta<0)
        {
            theta=M_PI+theta;
        }
    }
    else if(result0.y<0&&result0.x!=0)
    {
        theta=atan(result0.y/result0.x);
        if(theta<0)
        {
            theta=2*M_PI+theta;
        }
        else
        {
            theta+=M_PI;
        }
    }
    //偏移向量从图片坐标系映射到大地坐标系
    result0.x=kltDis*cos(theta+useYaw);
    result0.y=kltDis*sin(theta+useYaw);
//    fileTest<<"len: "<<kltDis<<endl;
//    fileTest<<"theta: "<<theta<<endl;

    return result0;
}
//int main()
//{
//    string path = "/home/ubuntu/Documents/UVA_OffLine/judge/";
////	string savePath = "E:\\OpenCV\\UVA\\Frame2\\2";
//	int id = 0;
//    Point2f result;
//    Mat imgA, imgB;
//
//    clock_t begin, end;
//    for (int i = 0; i < 10; i++)
//    {
//        char file1[50], file2[50];
//        sprintf(file1, "%d.jpg", id);
//        id += 5;
//        sprintf(file2, "%d.jpg", id);
//        string path1, path2;
//        path1 = path + file1;
//        path2 = path + file2;
//        imgA = imread(path1,0);
//        imgB = imread(path2,0);
//        begin = clock();
//        result = klt(imgA, imgB, 0.5);
//        end = clock();
//        cout << "image shift:(" << result.x << " , " << result.y << ")      " << (end-begin)/CLOCKS_PER_SEC << endl;
//        //imshow("Æ«ÒÆœá¹û", result);
//        //waitKey(50);
//        //imwrite(savePath + file1, result);
//    }
//    return 0;
//}
