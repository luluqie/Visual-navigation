#include <time.h>
#include "extract_descriptor.h"
#include "match.h"
using namespace std;
using namespace cv;
BruteForceMatcher<HammingLUT> threadMatcher;
/*
int ransacTest(const vector<DMatch>& matches, const vector<KeyPoint>& keypoints1,const vector<KeyPoint>& keypoints2, vector<DMatch>& outMatches)
������matches     ����ͼ���ƥ���
keypoints1  ��ͼ��������
keypoints2  ��ͼ��������
outMatches  ɸѡ���ƥ���
���أ�
˵�����Ե�ǰƥ�����RANSAC���ԣ������������ͬ�·���ͨ�����Ե�ƥ��
*/
int ransacTest(
    const vector<DMatch>& matches, const vector<KeyPoint>& keypoints1,
    const vector<KeyPoint>& keypoints2, vector<DMatch>& outMatches)
{
    clock_t s,e;
    //�����ߵ���С����
    double distance = 6.0;
    //���ŵȼ������ʣ�
    double confidence = 0.99;
    //��Keypointsת����Point2f
    vector<Point2f>points1, points2;
    if (matches.size() == 0) return -1;//����ƥ��ɹ��ĵ㣬�򷵻�
    for (auto &matchesRef : matches)
    {
        //��ͼ��ؼ���
        float x = keypoints1[matchesRef.queryIdx].pt.x;
        float y = keypoints1[matchesRef.queryIdx].pt.y;
        points1.push_back(Point2f(x, y));
        //��ͼ��ؼ���
        x = keypoints2[matchesRef.trainIdx].pt.x;
        y = keypoints2[matchesRef.trainIdx].pt.y;
        points2.push_back(Point2f(x, y));
    }
    //����RANSAC����F����
    s=clock();
    vector<uchar>inlines(points1.size(), 0);
    findFundamentalMat(
        Mat(points1),
        Mat(points2),
        inlines,
        CV_FM_RANSAC,
        distance,
        confidence
    );
    e=clock();
//    cout<<"thread id: "<<this_thread::get_id()<<endl;
//    cout <<"findFundamentalMat: "<<(float)(e-s)/CLOCKS_PER_SEC<<endl;
    //��ȡͨ����ƥ��
    vector<uchar>::const_iterator itIn = inlines.begin();
    vector<DMatch>::const_iterator itM = matches.begin();
    for (; itIn != inlines.end(); itIn++, itM++)
    {
        if (*itIn)
        {
            outMatches.push_back(*itM);
        }
    }
    return 0;
}

vector<Point2f> partMatchedWithOrb(vector<KeyPoint> keyPoints_1, vector<KeyPoint> keyPoints_2, Mat descriptors_1, Mat descriptors_2)
{
    const int radius = 300;//�뾶��ƽ��
    const int minPts = 4;//���Ķ�����Χ�����ٵ���

    vector<Point2f> returnResult;
    returnResult.push_back(Point2f(0, 0));
    returnResult.push_back(Point2f(0, 0));
    returnResult.push_back(Point2f(0, 0));
    returnResult.push_back(Point2f(0, 0));

    ORB orb;

    vector<Point2f> cokeyPointquery;

    BruteForceMatcher<HammingLUT> matcher;
    vector<DMatch> matches;
    if (descriptors_1.rows == 0 || descriptors_2.rows == 0)
        return returnResult;
    matcher.match(descriptors_1, descriptors_2, matches);

    vector< DMatch > outmatches;

    ransacTest(matches, keyPoints_1, keyPoints_2, outmatches);

    //�����ܶȾ���
    vector<Dbscan> pointListQuery, pointListTrain;//���е㼯
    vector<vector<int>> classSet;
    for (size_t i = 0; i < outmatches.size(); i++)//��������ƥ��㣬ѹ�뵽�㼯
    {

        cokeyPointquery.push_back(keyPoints_1[outmatches[i].queryIdx].pt);//ƥ��������

        Dbscan tmpPoint;
        tmpPoint.coordinate = keyPoints_1[outmatches[i].queryIdx].pt;
        tmpPoint.iscontained = false;
        tmpPoint.iscorePoint = false;
        pointListQuery.push_back(tmpPoint);

        tmpPoint.coordinate = keyPoints_2[outmatches[i].trainIdx].pt;
        tmpPoint.iscontained = false;
        tmpPoint.iscorePoint = false;
        pointListTrain.push_back(tmpPoint);
    }
    for (size_t i = 0; i < pointListQuery.size(); i++)//�����㼯���жϸ����Ƿ�Ϊ���Ķ��󣬹�����Ķ����ֱ���ܶȿɴ������
    {
        int pointNum = 0;
        Point2f tmp = pointListQuery[i].coordinate;
        float dx = 0;
        float dy = 0;
        for (size_t j = 0; j < pointListQuery.size(); j++)
        {
            dx = pointListQuery[j].coordinate.x - tmp.x;
            dy = pointListQuery[j].coordinate.y - tmp.y;
            if (dx*dx + dy*dy <= radius)
            {
                pointListQuery[i].reachable.push_back(j);
                pointNum++;
            }
        }
        if (pointNum >= minPts)//�ĵ��Ƿ��Ǻ��Ķ���
            pointListQuery[i].iscorePoint = true;
    }
    for (size_t i = 0; i < pointListQuery.size(); i++)//�Ժ��Ķ���������չֱ���ܶȿɴ�㼰����ܶȿɴ��
    {
        if (pointListQuery[i].iscorePoint == true)
        {
            if (pointListQuery[i].iscontained == false)
            {
                vector<int> tmpList = pointListQuery[i].reachable;
                vector<Dbscan> tmpQueue;
                int index;
                for (size_t j = 0; j < pointListQuery[i].reachable.size(); j++)
                {
                    index = pointListQuery[i].reachable[j];
                    if (pointListQuery[index].iscorePoint == true)
                    {
                        tmpQueue.push_back(pointListQuery[index]);
                        pointListQuery[index].iscontained = true;
                    }
                }
                while (!tmpQueue.empty())
                {
                    Dbscan tmp = tmpQueue.back();
                    tmpQueue.pop_back();
                    for (size_t j = 0; j < tmp.reachable.size(); j++)
                    {
                        if (!pointListQuery[tmp.reachable[j]].iscontained)
                        {

                            tmpList.push_back(tmp.reachable[j]);
                            if (pointListQuery[tmp.reachable[j]].iscorePoint)
                            {
                                tmpQueue.insert(tmpQueue.begin(), pointListQuery[tmp.reachable[j]]);
                                pointListQuery[tmp.reachable[j]].iscontained = true;
                            }
                        }
                    }
                }
                classSet.push_back(tmpList);
            }
        }
    }

    vector<int> maxArea;
    vector<int> secondArea;
    float area1 = 0;
    float area2 = 0;
    for (size_t i = 0; i < classSet.size(); i++)
    {
        Scalar color = Scalar(i * 125 % 255, i * 50 % 255, i * 20 % 255);
        vector<int> tmpList = classSet[i];

        float coorXQuery, coorYQuery, coorXTrain, coorYTrain;
        float minXQuery = 10000, maxXQuery = 0, minYQuery = 10000, maxYQuery = 0;
        for (size_t j = 0; j < tmpList.size(); j++)
        {
            //����ͼ�л��������
            coorXQuery = pointListQuery[tmpList[j]].coordinate.x;
            coorYQuery = pointListQuery[tmpList[j]].coordinate.y;

            if (coorXQuery > maxXQuery)
            {
                maxXQuery = coorXQuery;
            }
            if (coorXQuery < minXQuery)
            {
                minXQuery = coorXQuery;
            }
            if (coorYQuery > maxYQuery)
            {
                maxYQuery = coorYQuery;
            }
            if (coorYQuery < minYQuery)
            {
                minYQuery = coorYQuery;
            }
        }

        float minXTrain = 10000, maxXTrain = 0, minYTrain = 10000, maxYTrain = 0;
        for (size_t j = 0; j < tmpList.size(); j++)
        {
            //����ͼ�л��������
            coorXTrain = pointListTrain[tmpList[j]].coordinate.x;
            coorYTrain = pointListTrain[tmpList[j]].coordinate.y;

            if (coorXTrain > maxXTrain)
            {
                maxXTrain = coorXTrain;
            }
            if (coorXTrain < minXTrain)
            {
                minXTrain = coorXTrain;
            }
            if (coorYTrain > maxYTrain)
            {
                maxYTrain = coorYTrain;
            }
            if (coorYTrain < minYTrain)
            {
                minYTrain = coorYTrain;
            }
        }
        float areaRatio = 1.2;
        if ((maxXTrain - minXTrain)*(maxYTrain - minYTrain) / ((maxXQuery - minXQuery)*(maxYQuery - minYQuery)) < areaRatio && (maxXTrain - minXTrain)*(maxYTrain - minYTrain) / ((maxXQuery - minXQuery)*(maxYQuery - minYQuery)) > (1 / areaRatio))
        {
            if ((maxXQuery - minXQuery)*(maxYQuery - minYQuery)>area1)
            {
                secondArea = maxArea;
                area2 = area1;
                maxArea = tmpList;
                area1 = (maxXQuery - minXQuery)*(maxYQuery - minYQuery);
            }
            else if ((maxXQuery - minXQuery)*(maxYQuery - minYQuery) > area2)
            {
                secondArea = tmpList;
                area2 = (maxXQuery - minXQuery)*(maxYQuery - minYQuery);
            }
        }

    }

    //������������
    float coorXQuery, coorYQuery, coorXTrain, coorYTrain;
    float minXQuery = 10000, maxXQuery = 0, minYQuery = 10000, maxYQuery = 0;
    float centerXQuery = 0;
    float centerYQuery = 0;
    float centerXTrain = 0;
    float centerYTrain = 0;

    for (size_t i = 0; i < maxArea.size(); i++)
    {
        coorXQuery = pointListQuery[maxArea[i]].coordinate.x;
        coorYQuery = pointListQuery[maxArea[i]].coordinate.y;

        coorXTrain = pointListTrain[maxArea[i]].coordinate.x;
        coorYTrain = pointListTrain[maxArea[i]].coordinate.y;

        centerXQuery += coorXQuery;
        centerYQuery += coorYQuery;
        centerXTrain += coorXTrain;
        centerYTrain += coorYTrain;

        if (coorXQuery > maxXQuery)
        {
            maxXQuery = coorXQuery;
        }
        if (coorXQuery < minXQuery)
        {
            minXQuery = coorXQuery;
        }
        if (coorYQuery > maxYQuery)
        {
            maxYQuery = coorYQuery;
        }
        if (coorYQuery < minYQuery)
        {
            minYQuery = coorYQuery;
        }
    }
    if (maxArea.size() != 0)
    {
        centerXQuery = centerXQuery / maxArea.size();
        centerYQuery = centerYQuery / maxArea.size();
        centerXTrain = centerXTrain / maxArea.size();
        centerYTrain = centerYTrain / maxArea.size();

        returnResult[0].x = centerXQuery;
        returnResult[0].y = centerYQuery;
        returnResult[1].x = centerXTrain;
        returnResult[1].y = centerYTrain;
    }

    //�����δ������
    minXQuery = 10000;
    maxXQuery = 0;
    minYQuery = 10000;
    maxYQuery = 0;
    centerXQuery = 0;
    centerYQuery = 0;
    centerXTrain = 0;
    centerYTrain = 0;

    for (size_t i = 0; i < secondArea.size(); i++)
    {
        coorXQuery = pointListQuery[secondArea[i]].coordinate.x;
        coorYQuery = pointListQuery[secondArea[i]].coordinate.y;

        coorXTrain = pointListTrain[secondArea[i]].coordinate.x;
        coorYTrain = pointListTrain[secondArea[i]].coordinate.y;

        centerXQuery += coorXQuery;
        centerYQuery += coorYQuery;
        centerXTrain += coorXTrain;
        centerYTrain += coorYTrain;

        if (coorXQuery > maxXQuery)
        {
            maxXQuery = coorXQuery;
        }
        if (coorXQuery < minXQuery)
        {
            minXQuery = coorXQuery;
        }
        if (coorYQuery > maxYQuery)
        {
            maxYQuery = coorYQuery;
        }
        if (coorYQuery < minYQuery)
        {
            minYQuery = coorYQuery;
        }
    }
    if (secondArea.size() != 0)
    {
        centerXQuery = centerXQuery / secondArea.size();
        centerYQuery = centerYQuery / secondArea.size();
        centerXTrain = centerXTrain / secondArea.size();
        centerYTrain = centerYTrain / secondArea.size();

        returnResult[2].x = centerXQuery;
        returnResult[2].y = centerYQuery;
        returnResult[3].x = centerXTrain;
        returnResult[3].y = centerYTrain;
    }
    return returnResult;
}
int matchedWithOrbXML(vector<KeyPoint> keyPoints_1, vector<KeyPoint> keyPoints_2, Mat descriptors_1, Mat descriptors_2)
{
    BruteForceMatcher<HammingLUT> matcher;
    vector<DMatch> matches;
    if (descriptors_1.rows == 0 || descriptors_2.rows == 0)
        return 0;
    matcher.match(descriptors_1, descriptors_2, matches);

    vector< DMatch > outmatches;
    ransacTest(matches, keyPoints_1, keyPoints_2, outmatches);

    return outmatches.size();
}

/*
void matchedByThread(vector<KeyPoint>& keyPoints_1, Mat& descriptors_1, vector<matchedPic> *picSet, int begin, int end)
������keyPoints_1  ��ǰͼ��������
      descriptors_1  ��ǰͼ��������
	  picSet  ��ƥ��ͼ�񼯺ϣ�
���أ�void
˵�������ڶ��̵߳���
*/
void matchedByThread(vector<KeyPoint> keyPoints_1, Mat descriptors_1, vector<matchedPic> *picSet)
{
	vector<KeyPoint> keyPoints_2;
	Mat descriptors_2;

	vector<DMatch> matches;
	vector< DMatch > outmatches;

	for (unsigned int i = 0; i < (*picSet).size(); ++i)
	{
		keyPoints_2 = (*picSet)[i].keypoints;
		descriptors_2 = (*picSet)[i].descriptor;

		threadMatcher.match(descriptors_1, descriptors_2, matches);
		ransacTest(matches, keyPoints_1, keyPoints_2, outmatches);
		(*picSet)[i].matchedNum = outmatches.size();
		//cout << "picSet[i].matchedNum:" << picSet[i].picNum << endl;
//		    cout<<"thread id: "<<this_thread::get_id()<<endl;

	}
}
/*
Point2f matchWithIndexXML(Mat img, double longitude, double latitude)
������img  ��ǰͼ
      longitude  ��ǰͼ���ȵĹ���ֵ
	  latitude  ��ǰͼγ�ȵĹ���ֵ
���أ�perfectGPS  �����ֲ�ƥ������ľ�γ��
˵����
*/
Point2f matchWithIndexXML(Mat src_img, float yaw, double longitude, double latitude)
{
    Mat img;

    img = ResizeImage(src_img,0.5);

	Point2f perfectGPS;
	perfectGPS.x=-1;
	perfectGPS.y=-1;

    rotationWithoutChangeSize(img,yaw);

	ORB orb;
	vector<KeyPoint> keyPoints_1, keyPoints_2;
	Mat descriptors_1, descriptors_2;

	orb(img, Mat(), keyPoints_1, descriptors_1);//��ȡ��ǰͼ�������㡢������

	string descriptorFolderPath = "/home/ubuntu/catkin_ws/src/dji_ros/Onboard-SDK-ROS/uva_visual_guidence/xml/descriptor/";
	string coordinateFolderPath = "/home/ubuntu/catkin_ws/src/dji_ros/Onboard-SDK-ROS/uva_visual_guidence/xml/coordinate/";
	string descriptorPath, coordinatePath;
	char descriptorName[50];
	char coordinateName[50];
//	char imgPath[50];

	double radius = 0.000200;

	Mat baseMap;
	Gps gps[NUM];
	vector<Gps> returnResult;
	int length = loadGPS(gps, "/home/ubuntu/catkin_ws/src/dji_ros/Onboard-SDK-ROS/uva_visual_guidence/xml/order_gps_toNorth.txt");//��׼��ͼ����

	Gps result[50];//��෵��һ���ţ�����;
	int imgNum;
	int matchedNum = 0;
	int maxMathed = 0;
	int maxMatchedImgNum = -1;
	double latit = 0, longit = 0;
	int resultSize = gpscollection(gps, result, length, longitude, latitude, radius);//���صĴ�ƥ��ͼƬ��
	//cout << result[0].latitude << "  " << result[0].longitude << endl;
	//cout << "resultsize = " << resultSize << endl;
	matchedPic tmpMatch;

	vector<matchedPic> picSet;
//resultSize=resultSize>10?10:resultSize;
	for (int i = 0; i < resultSize; i++)
	{
		imgNum = result[i].picname;
		sprintf(descriptorName, "descriptor_%d.xml", imgNum);
		sprintf(coordinateName, "coordinate_%d.xml", imgNum);

		keyPoints_2 = getKeyPointFromFile(coordinateFolderPath, coordinateName);
		descriptors_2 = getDescriptorFromFile(descriptorFolderPath, descriptorName);

		tmpMatch.descriptor = descriptors_2;
		tmpMatch.keypoints = keyPoints_2;
		tmpMatch.matchedNum = -1;
		tmpMatch.picNum = result[i].picname;
		tmpMatch.latitude = result[i].latitude;
		tmpMatch.longitude = result[i].longitude;

		picSet.push_back(tmpMatch);
	}
	if (resultSize > 0)
	{
		int currentThreadNum = 0;
		int threadNum;
		threadNum = resultSize >20? 20: resultSize;

		vector<vector<matchedPic>> partPicSet(threadNum);
		vector<matchedPic> tmpPicSet;
		vector<thread> threadSet;
		    clock_t start,finish;

    start=clock();
		//cout << resultSize << endl;
		for (int i = 0; i < resultSize; ++i)
		{
			partPicSet[currentThreadNum].push_back(picSet[i]);
			currentThreadNum = (currentThreadNum + 1) % threadNum;
		}

		for (int i = 0; i < threadNum; ++i)
		{
			if (!partPicSet[i].empty())
			{
				threadSet.push_back(thread(matchedByThread, keyPoints_1, descriptors_1, &(partPicSet[i])));
			}
		}

		for (auto &ts : threadSet)
		{
			ts.join();
		}
//		threadSet[7].join();
        finish=clock();
      cout <<"timer: "<<(float)(finish-start)/CLOCKS_PER_SEC<<endl;

	}

	set<matchedPic> matchedSet;
	set<matchedPic>::iterator it;

	for (int i = 0; i < resultSize; i++)
	{
		matchedNum = picSet[i].matchedNum;
		tmpMatch.matchedNum = picSet[i].matchedNum;
		tmpMatch.picNum = picSet[i].picNum;
		tmpMatch.latitude = picSet[i].latitude;
		tmpMatch.longitude = picSet[i].longitude;

		if (matchedSet.size() < 5)
		{
			matchedSet.insert(tmpMatch);
		}
		else
		{
			if (tmpMatch.matchedNum > (*matchedSet.rbegin()).matchedNum)//���˴�ƥ����������Ѽ�¼����С��������ɾ�����һ��Ԫ�أ���Сƥ�䣩���ٲ���
			{
				it = matchedSet.end();
				matchedSet.erase(--it);
				matchedSet.insert(tmpMatch);
			}
		}
		if (matchedNum > maxMathed)
		{
			maxMathed = matchedNum;
			maxMatchedImgNum = imgNum;
			latit = picSet[i].latitude;
			longit = picSet[i].longitude;
		}
	}
	it = matchedSet.begin();
	double longi = 0;
	double lati = 0;
	double shiftLongi = 0;
	double shiftLati = 0;
	vector<Point2f> matchedCenter, matchedCenter2;
	Point2f movedVector1(0, 0);
	Point2f movedVector2(0, 0);

	for (int flag = 0; it != matchedSet.end(); it++, flag++)
	{
		imgNum = (*it).picNum;
		sprintf(descriptorName, "descriptor_%d.xml", imgNum);
		sprintf(coordinateName, "coordinate_%d.xml", imgNum);
		descriptorPath = descriptorFolderPath + descriptorName;
		coordinatePath = coordinateFolderPath + coordinateName;
		keyPoints_2 = getKeyPointFromFile(coordinateFolderPath, coordinateName);
		descriptors_2 = getDescriptorFromFile(descriptorFolderPath, descriptorName);

//		sprintf(imgPath, "resource/images/%d.jpg", imgNum);

		matchedCenter = partMatchedWithOrb(keyPoints_1, keyPoints_2, descriptors_1, descriptors_2);
		movedVector1.x = 0.5*img.cols - (matchedCenter[0].x + 0.5*img.cols - matchedCenter[1].x);
		movedVector1.y = 0.5*img.rows - (matchedCenter[0].y + 0.5*img.rows - matchedCenter[1].y);

		movedVector2.x = 0.5*img.cols - (matchedCenter[2].x + 0.5*img.cols - matchedCenter[3].x);
		movedVector2.y = 0.5*img.rows - (matchedCenter[2].y + 0.5*img.rows - matchedCenter[3].y);

		//cout << "matchedNum: " << (*it).matchedNum << "  picNum; " << (*it).picNum << endl;
		longi += (*it).longitude + 0.5*(movedVector1.x + movedVector2.x) * 0.000007369;
		lati += (*it).latitude - 0.5*(movedVector1.y + movedVector2.y) * 0.000006175;

		if (flag == 0)
		{
			shiftLongi = longi;
			shiftLati = lati;
		}
	}
	double meanLatitude, meanLongitude;
	if (matchedSet.size() != 0)
	{
		meanLatitude = lati / matchedSet.size();
		meanLongitude = longi / matchedSet.size();
	}
	else
	{
		meanLatitude = -1;
		meanLongitude = -1;
	}

	perfectGPS.x = meanLongitude;
	perfectGPS.y = meanLatitude;

	return perfectGPS;
}

//int main()
//{
//
//    clock_t start,finish;
//    Mat current = imread("/home/ubuntu/Desktop/1957.jpg",0);
//
//    resize(current, current, Size(), 0.5, 0.5);
//    cout<<"hardware_num: "<<thread::hardware_concurrency()<<endl;
////    start=clock();
//    for(int i=0;i<10;i++)
//    Point2f result = matchWithIndexXML(current, 103.927123, 30.751888);
////    finish=clock();
////    cout <<"timer: "<<(float)(finish-start)/CLOCKS_PER_SEC<<endl<< fixed << result.x << " " << result.y << endl;
//    cout<<"thread id: "<<this_thread::get_id()<<endl;
//
//    cout << "nothing wrong!" << endl;
//    return 0;
//}

