﻿//
//  findGPS.cpp
//  abc
//
//  Created by 温尔雅 on 16/4/22.
//  Copyright © 2016年 温尔雅. All rights reserved.
//

#include "../include/findGPS.h"

/*
*从文本中加载gps到结构数组
*@Param
*fdir:要打开的文件名
*gps:加载数据到gps结构数组中
*/
int loadGPS(Gps* gps, string fdir){
	ifstream infile(fdir);

	if (!infile.is_open())
	{
		cout << "No such file!" << endl;
		abort();
	}


	if (!infile.is_open())
	{
		cout << "No such file!" << endl;
		abort();
	}

	int num = 0;
	while (!infile.eof()){
		infile >> gps[num].longitude;
		infile >> gps[num].latitude;
		infile >> gps[num].yaw;
		infile >> gps[num].picname;
		num++;
	}
	return num;
}

/*
*gps结构数组中查找指定的value
*@Param
*low:数组左边界
*high:数组右边界
*value:待查的值
*isLongti:查找的是经度还是纬度，true为经度
*@Return
*返回数组中不大于该数的最大数位置
*/
int binarySearch(Gps* gps, int low, int high, double value, bool isLongti){
	int position = -1;
	if (low>high){
		return -1;
	}
	int mid = (low + high) / 2;
	if (isLongti){
		if ((gps[mid].longitude >= value&&gps[mid - 1].longitude <= value) || (gps[mid].longitude <= value&&gps[mid + 1].longitude >= value)){
			return position = gps[mid].longitude <= value ? mid : mid - 1;
		}
		else if (gps[mid].longitude<value&&gps[mid + 1].longitude < value){
			return binarySearch(gps, mid + 1, high, value, isLongti);
		}
		else if (gps[mid].longitude > value&&gps[mid - 1].longitude>value){
			return binarySearch(gps, low, mid - 1, value, isLongti);
		}
	}
	else{
		if ((gps[mid].latitude >= value&&gps[mid - 1].latitude <= value) || (gps[mid].latitude <= value&&gps[mid + 1].latitude >= value)){
			return position = gps[mid].latitude <= value ? mid : mid - 1;
		}
		else if (gps[mid].latitude<value&&gps[mid + 1].latitude<value){
			return binarySearch(gps, mid + 1, high, value, isLongti);
		}
		else if (gps[mid].latitude>value&&gps[mid - 1].latitude>value) {
			return binarySearch(gps, low, mid - 1, value, isLongti);
		}
	}

	return position;
}

/*
*输入经度和查找范围，输出数组，数组元素是在范围内的图片名称和gps
*@Param
*gps:gps数组，在其中定位
*length: 数组长度
*lati:待查找的经度
*scope:查找范围
*@Return
*gps结构数组，数组元素里是在范围里的gps和图片名
*/
#define MAXNum 40

int gpscollection(Gps* gps, Gps* result, int length, double longit, double latit, double scope){
	//  Gps result[100];
	//Gps* temp = new Gps[100];//最多返回一百张！！！
	int return_img_num = MAXNum;
	double upperbound = longit + scope;
	double lowerbound = longit - scope;

	int lower_position = binarySearch(gps, 0, length, lowerbound, true);
	int upper_position = binarySearch(gps, lower_position, length, upperbound, true) + 1;

	if (lower_position < 0)
	{
		lower_position = 0;
	}
	int gap = (int)ceil((double)(upper_position - lower_position) / MAXNum);
	//cout << "upper_position - lower_position:" << upper_position - lower_position << "  MAX" << MAX << endl;
	//cout << "gap:"<< gap << endl;
	return_img_num = upper_position - lower_position < MAXNum ? upper_position - lower_position - 1 : (upper_position - lower_position) / gap;//如果返回的图片张数超过限定值则取限定值
	int returnNum = 0;
	//cout << "return number:" << upper_position - lower_position << "  gap:" << gap << "  return_img_num:" << return_img_num << endl;
	for (int j = 0; lower_position + j < upper_position;){//lower_position从下一张开始是符合条件的图片
		if (gps[lower_position + j].latitude > latit - scope && gps[lower_position + j].latitude < latit + scope)
		{
			result[returnNum].latitude = gps[lower_position + j].latitude;
			result[returnNum].longitude = gps[lower_position + j].longitude;
			result[returnNum].yaw = gps[lower_position + j].yaw;
			result[returnNum].picname = gps[lower_position + j].picname;

			returnNum++;
			j += gap;
		}
		else
		{
			j++;
		}
	}
	return returnNum;
}

