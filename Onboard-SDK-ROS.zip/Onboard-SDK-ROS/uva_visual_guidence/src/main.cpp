#include "../include/main.hpp"

// ===================================================================
// msg publisher, the subscriber is in dji_sdk_demo/client.cpp
#define LINK_VISUAL_MSG

#ifdef LINK_VISUAL_MSG
#include "dji_sdk_demo/dji_info.h"
#include "dji_sdk_demo/landmark_info.h"
#endif
// ===================================================================

int main(int argc, char **argv)
{

    float useYaw=0,curYaw=0;//useYaw是上一帧图片获取时的夹角，curYaw是当前图获取时夹角
    struct LandData landData;
    landData.delta.x=0;
    landData.delta.y=0;
    landData.coefficient=0;
    clock_t start,finish;
    float startHeight=0,curHeight=0;//记录起始位置高度和当前位置高度
    ros::init(argc,argv,"image_raw");
    ROS_INFO("sdk_service_attitude");
    ros::NodeHandle nh;
    DJIDrone* drone = new DJIDrone(nh);
    Point2f currentPt;//起飞点横纵坐标，全程记录纯klt的位置
    Point2f matchPt;//加权klt后的匹配坐标点
    Point2f matchKltPt;//currentPt和matchPt加权输出的位置
    Point2f gps;//输出的当前位置gps
    int ret,nKey;
    bool isFirst=true,firstImg=true,isLand=false;//isLand——飞机达到250米后方可降落
    int nState = 1;
    int nCount = 1,startCount=0;//记录摄像头传回的照片帧编号数,到达250米的第一张照片编号
    string imageDir=getcwd(NULL,0)+std::string("/src/dji_ros/Onboard-SDK-ROS/uva_visual_guidence/images/");
    unsigned char buffer[FRAME_SIZE] = {0};
    unsigned int frame_size = 0;
    unsigned int nframe = 0;
    FILE *fp;
    long count=0;
    double hu_base[7];//存储基准降落图的信息
    time_t timep;
    clock_t begin, end;
    ofstream fileBase ("/home/ubuntu/catkin_ws/src/dji_ros/Onboard-SDK-ROS/uva_visual_guidence/flyData/base.txt");
    ofstream fileCalc("/home/ubuntu/catkin_ws/src/dji_ros/Onboard-SDK-ROS/uva_visual_guidence/flyData/calc.txt");
    ofstream fileLand("/home/ubuntu/catkin_ws/src/dji_ros/Onboard-SDK-ROS/uva_visual_guidence/flyData/land_main.txt");
    ofstream fileTest("/home/ubuntu/catkin_ws/src/dji_ros/Onboard-SDK-ROS/uva_visual_guidence/flyData/test.txt");
//    time_t timep;
    Mat curImg,beforeImg;
#ifdef RGB
    IplImage * pRawImg = cvCreateImage(cvSize(IMAGE_W, IMAGE_H),IPL_DEPTH_8U,3);
    IplImage * pImg = cvCreateImage(cvSize(640, 480),IPL_DEPTH_8U,3);
    unsigned char * pData  = new unsigned char[1280 * 720 * 3];
#else
    IplImage * pRawImg = cvCreateImage(cvSize(IMAGE_W, IMAGE_H),IPL_DEPTH_8U,1);
    IplImage * pImg = cvCreateImage(cvSize(640, 480),IPL_DEPTH_8U,1);
#endif

    ros::NodeHandle node;
    image_transport::ImageTransport transport(node);
    image_transport::Publisher image_pub = transport.advertise("dji_sdk/image_raw", 1);
    ros::Publisher caminfo_pub = node.advertise<sensor_msgs::CameraInfo>("dji_sdk/camera_info",1);

    ros::Time time=ros::Time::now();

    cv_bridge::CvImage cvi;


    sensor_msgs::Image im;
    sensor_msgs::CameraInfo cam_info;

    cam_info.header.frame_id = "/camera";
    cam_info.height = IMAGE_H/2;
    cam_info.width = IMAGE_W/2;
    cam_info.distortion_model = "";
    cam_info.D.push_back(-0.1297646493949856);
    cam_info.D.push_back(0.0946885697670611);
    cam_info.D.push_back(-0.0002935002712265514);
    cam_info.D.push_back(-0.00022663675362156343);
    cam_info.D.push_back(0.0);
    cam_info.K = {388.40923066779754, 0.0, 318.06257844065226, 0.0, 518.1538449374815, 241.17339016626644, 0.0, 0.0, 1.0};
    cam_info.R = {1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0};
    cam_info.P = {373.5429992675781, 0.0, 317.51131336952494, 0.0, 0.0, 504.4360656738281, 240.6131009245937, 0.0, 0.0, 0.0, 1.0, 0.0};
    cam_info.binning_x = 0;
    cam_info.binning_x = 0;

    cam_info.roi.x_offset = 0;
    cam_info.roi.y_offset = 0;
    cam_info.roi.height = 0;
    cam_info.roi.width = 0;
    cam_info.roi.do_rectify = false;

    ret = manifold_cam_init(mode);
    if(ret == -1)
    {
        printf("manifold init error \n");
        return -1;
    }

    // ===================================================================
    // alex, publish gps
#ifdef LINK_VISUAL_MSG
    ros::NodeHandle n;
    ros::Publisher visual_gps_pub = n.advertise<dji_sdk_demo::dji_info>("visual_gps",10);
    dji_sdk_demo::dji_info visual_gps_msg;
    ros::Publisher landmark_info_pub = n.advertise<dji_sdk_demo::landmark_info>("landmark_info",10);
    dji_sdk_demo::landmark_info landmark_info_msg;
#endif
    // ===================================================================



//循环获取摄像头数据
    while(1)
    {
        sleep(0.5);

#ifdef RGB
//            NV12ToRGB(buffer,pData,1280,720);
        memcpy(pRawImg->imageData,pData,FRAME_SIZE);
#else
        memcpy(pRawImg->imageData,buffer,FRAME_SIZE/3);
#endif
        cvResize(pRawImg,pImg,CV_INTER_LINEAR);
        time=ros::Time::now();
        cvi.header.stamp = time;
        cvi.header.frame_id = "image";
#ifdef RGB
        cvi.encoding = "bgr8";
#else
        cvi.encoding = "mono8";
#endif
        cvi.image = pImg;
        cvi.toImageMsg(im);
        cam_info.header.seq = nCount;
        cam_info.header.stamp = time;
        caminfo_pub.publish(cam_info);
        image_pub.publish(im);
        ros::spinOnce();
        ret = manifold_cam_read(buffer, &nframe, 1);
        cout<<"ret:"<<ret<<endl;
        cout<<"status: "<<unsigned(drone->flight_status)<<endl;
        Mat mat_img(pRawImg);
        // ===================================================================
        // Alex write image into a folder, the image will be transfered to GCS
#ifdef LINK_VISUAL_MSG
        Mat img_dji_before = mat_img;
        Mat img_dji;
        Size img_dji_size(img_dji_before.cols*0.1,img_dji_before.rows*0.1);
        resize(img_dji_before,img_dji,img_dji_size,0.1,0.1);

        finish=clock();
        fileTest<<"current time before: "<<(double)(finish)/CLOCKS_PER_SEC<<endl;
        imwrite("/home/ubuntu/catkin_ws/src/dji_ros/Onboard-SDK-ROS/uva_visual_guidence/image_gcs/img_dji.jpg",img_dji);

        finish=clock();
        fileTest<<"current time after: "<<(double)(finish)/CLOCKS_PER_SEC<<endl;
        //visual_gps_msg.lat = 99.9f;
        //visual_gps_msg.lon = 99.9f;
        //visual_gps_pub.publish(visual_gps_msg);
#endif
        // ===================================================================

        if(ret != -1&&(unsigned(drone->flight_status)==3))//摄像头获取数据正确且飞行状态为在空中
        {
            //起飞的第一帧获取起飞高度、起飞坐标
            if(isFirst)
            {

                startHeight=drone->global_position.height;
                Point2f startGps;
                startGps.x=drone->global_position.longitude;
                startGps.y=drone->global_position.latitude;
                matchKltPt=currentPt=calCoorFromGps(startGps);
                isFirst=false;
                fileTest<<"startCoor: "<<currentPt.x<<":"<<currentPt.y<<endl;
                fileTest<<"startHeight: "<<startHeight<<endl;
            }

            //起飞后获取实时高度
            fileTest<<"nCount: "<<nCount<<endl;
            curHeight=drone->global_position.height;
            fileTest<<"curHeight: "<<curHeight<<endl;

            //打开摄像头后拿到的前两帧照片失败，跳过
            if(nCount!=1&&nCount!=2&&(abs(curHeight-startHeight)>=250))
            {
                isLand=true;
                if (fileBase.is_open())
                {
//                time(&timep);
//                fileBase<<"time: "<<asctime(gmtime(&timep))<<endl;
                    fileBase<<setiosflags(ios::fixed)<<setprecision(6)<<"gimbal: "<<endl<<drone->gimbal<<endl;
                    fileBase<<setiosflags(ios::fixed)<<setprecision(6)<<"global_position: "<<endl<<drone->global_position<<endl;
                }
                curImg=mat_img;
                //获取飞机当前倾角并调整到以opencv图像坐标系一致的极坐标系
                curYaw=drone->gimbal.yaw;
                curYaw=curYaw/180*M_PI;
                if(firstImg) //第一次执行算法当前图和先前图一致
                {
                    beforeImg=curImg;
                    useYaw=curYaw;
                    firstImg=false;
                    startCount=nCount;//保存到达250米的第一张照片高度
                }
                else
                {
                    beforeImg=imread(imageDir+"before.jpg",0);
                }

                imwrite(imageDir+"before.jpg",curImg);//当前图写入作为下一次比较的基准图
                imwrite(imageDir+int2String(nCount)+".jpg",curImg);
                start=clock();
                Point2f result0=klt(beforeImg,curImg,(double)0.48);//250左右高度相对基准图需要缩放到0.4倍
                fileTest<<setiosflags(ios::fixed)<<setprecision(6)<<"result_before: "<<result0.x<<" : "<<result0.y<<endl;
                beforeImg=curImg;//更新前一帧图片
                Point2f result1=changeAxes(result0,useYaw);
                currentPt+=result1;//将opencv图片坐标系映射到大地基准坐标系
                matchKltPt+=result1;
                finish=clock();
                fileTest<<"time: "<<(double)(finish-start)/CLOCKS_PER_SEC<<endl;
                useYaw=curYaw;
                fileTest<<"useyaw: "<<useYaw<<endl<<"curYaw: "<<curYaw<<endl;
                fileTest<<setiosflags(ios::fixed)<<setprecision(6)<<"result_after: "<<result1.x<<" : "<<result1.y<<endl;
                if((nCount-startCount)%30==29)//180次klt后执行一次匹配
                {
                    Point2f result = matchWithIndexXML(curImg, curYaw, gps.x, gps.y);//此处仅计算匹配，未改变值
                    if(result.x!=-1&&result.y!=-1)
                    {
                        matchPt=0.7*calCoorFromGps(result)+0.3*matchKltPt;//加权平均得到最新的位置坐标
                    }
                    matchKltPt=0.1*currentPt+0.9*matchPt;
//                    matchKltPt=matchPt;
                    fileCalc<<setiosflags(ios::fixed)<<setprecision(6)<<"result.x: "<<result.x<<endl;
                    fileCalc<<setiosflags(ios::fixed)<<setprecision(6)<<"result.y: "<<result.y<<endl;
                    fileCalc<<setiosflags(ios::fixed)<<setprecision(6)<<"match.x: "<<calGpsFromCoor(matchPt).x<<endl;
                    fileCalc<<setiosflags(ios::fixed)<<setprecision(6)<<"match.y: "<<calGpsFromCoor(matchPt).y<<endl;
                }
                gps=calGpsFromCoor(matchKltPt);//纯klt和匹配的加权平均
                fileCalc<<setiosflags(ios::fixed)<<setprecision(6)<<"longitude: "<<gps.x<<endl;
                fileCalc<<setiosflags(ios::fixed)<<setprecision(6)<<"latitude: "<<gps.y<<endl;

                // ===================================================================

                // alex
#ifdef LINK_VISUAL_MSG
                visual_gps_msg.lat = (float)gps.y;
                visual_gps_msg.lon = (float)gps.x;
                visual_gps_pub.publish(visual_gps_msg);
#endif
                // ===================================================================

            }
            else if(isLand&&curHeight<=52&&curHeight>=18)
            {
                begin=clock();
                if(hu_base[0]==0&&hu_base[1]==0)
                {
                    getLandBase(hu_base);
                }
                imwrite("/home/ubuntu/catkin_ws/src/dji_ros/Onboard-SDK-ROS/uva_visual_guidence/flyData/"+int2String(nCount)+".jpg",curImg);
                fileLand<<"count: "<<nCount<<endl;
                fileLand<<"land.x_before: "<<landData.delta.x<<endl;
                fileLand<<"land.y_before: "<<landData.delta.y<<endl;
                landData=land(curImg,curHeight,hu_base,fileLand);
                end=clock();
                fileLand<<"timer: "<<(float)(end-begin)/CLOCKS_PER_SEC<<endl;
                fileLand<<"land.x: "<<landData.delta.x<<endl;
                fileLand<<"land.y: "<<landData.delta.y<<endl;
                fileLand<<"land.coefficient: "<<landData.coefficient<<endl;
                // ===================================================================
                // alex
                landmark_info_msg.dx = landData.delta.x;
                landmark_info_msg.dy = landData.delta.y;
                landmark_info_msg.h_ratio = landData.coefficient;
                landmark_info_pub.publish(landmark_info_msg);
                // ===================================================================
            }
            nCount++;
        }
        else
        {
            continue;
        }
    }
    while(!manifold_cam_exit())
    {
        sleep(1);
    }

    fclose(fp);
    sleep(1);
    return 0;
}
