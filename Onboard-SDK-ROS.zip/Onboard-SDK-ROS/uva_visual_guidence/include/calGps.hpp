#include<iostream>
#include<opencv2/features2d/features2d.hpp>

using namespace std;
using namespace cv;
Point2f calGpsFromCoor(Point2f);
Point2f calCoorFromGps(Point2f);
