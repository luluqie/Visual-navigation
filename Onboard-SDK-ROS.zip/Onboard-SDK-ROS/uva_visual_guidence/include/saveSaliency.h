#ifndef SAVESALIENCY_H
#define SAVESALIENCY_H

#include "saliency.h"

#include <opencv/cv.h>
#include <opencv/cxcore.h>
#include <opencv/highgui.h>

#include <iostream>
#include <cassert>


int SaveSaliency(string InputPath, string SavePath);

#endif