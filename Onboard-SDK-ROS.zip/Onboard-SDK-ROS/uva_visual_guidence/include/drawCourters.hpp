//
//  drawCourters.hpp
//  temp
//
//  Created by Kerwin_You on 15/12/16.
//  Copyright © 2015年 ___Kerwin___. All rights reserved.
//

#ifndef drawCourters_hpp
#define drawCourters_hpp

#include <stdio.h>
#include<opencv/cv.h>
#include<opencv/highgui.h>
#include <opencv2/core/core.hpp>
#include <fstream>
using namespace std;
using namespace cv;
vector<vector<Point>> drawCourters(Mat image,int,int ,int);
#endif /* drawCourters_hpp */
