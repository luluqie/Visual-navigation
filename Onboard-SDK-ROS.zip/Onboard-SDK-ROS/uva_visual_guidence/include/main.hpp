#include "ros/ros.h"
#include <dji_sdk/dji_drone.h>
#include <cstdlib>
#include <actionlib/client/simple_action_client.h>
#include <actionlib/client/terminal_state.h>
#include <fstream>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <sensor_msgs/CameraInfo.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <poll.h>
#include <signal.h>
#include <assert.h>
#include <sys/types.h>
#include <unistd.h>
#include <time.h>
#include "cv.h"
#include "highgui.h"
#include "djicam.h"
#include "calGps.hpp"
#include "extract_descriptor.h"
#include "calCoordinate.hpp"
#include "klt.hpp"
#include "match.h"
#include "path.hpp"
#include "land.hpp"
#include <iostream>
#include <iomanip>
#include <opencv2/features2d/features2d.hpp>
#include "utils.hpp"
using namespace std;
using namespace cv;
typedef unsigned char   BYTE;
#define IMAGE_W 1280
#define IMAGE_H 720
#define FRAME_SIZE              IMAGE_W*IMAGE_H*3

//#define RGB
#define mode GETBUFFER_MODE
