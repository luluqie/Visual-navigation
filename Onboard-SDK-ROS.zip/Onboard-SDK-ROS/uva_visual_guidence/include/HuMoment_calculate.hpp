//
//  HuMoment_calculate.hpp
//  temp
//
//  Created by Kerwin_You on 15/12/16.
//  Copyright © 2015年 ___Kerwin___. All rights reserved.
//

#ifndef HuMoment_calculate_hpp
#define HuMoment_calculate_hpp

#include <stdio.h>
#include <iostream>

#include<opencv/cv.h>
#include<opencv/highgui.h>
using namespace std;
using namespace cv;

bool huMoment_calculate(vector<Point> contours,double[],ofstream& fileLand);
#endif /* HuMoment_calculate_hpp */
