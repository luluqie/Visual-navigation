﻿//  findGPS.hpp
//  abc
//
//  Created by 温尔雅 on 16/4/22.
//  Copyright © 2016年 温尔雅. All rights reserved.
//

#ifndef findGPS_hpp
#define findGPS_hpp

#include "../include/util.h"
#include <iostream>
#include <fstream>
using namespace std;
int binarySearch(Gps*, int, int, double, bool);
int loadGPS(Gps*, string str);
int gpscollection(Gps* gps, Gps* result, int length, double longit, double latit, double scope);

#endif /* findGPS_hpp */
