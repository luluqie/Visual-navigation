#include<iostream>
#include<opencv2/features2d/features2d.hpp>
#include<math.h>
using namespace std;
using namespace cv;
#define CENTERX   3840*0.12/2  //当前采集图中心点在opencv坐标系中的横坐标，依据不同高度缩放的比例来修改，1080*ratio/2
#define CENTERY   2160*0.12/2  //当前采集图中心点在opencv坐标系中的纵坐标,720*ratio/2
Point2f calMatchCoordinate(vector<Point2f>,float);
