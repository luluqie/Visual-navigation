#ifndef UTIL_H
#define UTIL_H

#include <opencv2/opencv.hpp>
#include <iostream>

using namespace std;
using namespace cv;

#define NUM 10000
struct Gps{
	double  latitude;
	double  longitude;
	double  yaw;
	int picname;
};
struct matchedPic
{
	int matchedNum;
	int picNum;
	double longitude;
	double latitude;
	vector<KeyPoint> keypoints;
	Mat descriptor;

	bool operator < (const matchedPic &rhs) const
	{
		return rhs.matchedNum < matchedNum;
	}
};
struct Dbscan
{
	Point2f coordinate;
	bool iscorePoint;
	bool iscontained;
	vector<int> reachable;//ֱ���ܶȿɴ�������
};

#endif
