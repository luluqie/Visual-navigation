//
//  land.hpp
//  temp
//
//  Created by Kerwin_You on 15/12/13.
//  Copyright © 2015年 ___Kerwin___. All rights reserved.
//

#ifndef land_hpp
#define land_hpp

#include <stdio.h>
#include<iostream>
#include <opencv2/core/core.hpp>
#include<opencv/cv.h>
#include<opencv/highgui.h>
#include "../include/drawCourters.hpp"
#include "../include/HuMoment_calculate.hpp"
#include <fstream>
using namespace std;
using namespace cv;
struct LandData{
    Point delta;
    float coefficient;
};
struct LandData land(Mat,float,double[],ofstream&);
void getLandBase(double hu[]);
#endif /* land_hpp */
