#ifndef AbstractSalientRegion_H
#define AbstractSalientRegion_H

#include<opencv2/highgui/highgui.hpp>
#include<opencv2/imgproc/imgproc.hpp>

#include<vector>
#include<set>
#include"iostream"

using namespace std;
using namespace cv;

class SalientRegion
{
public:
	int minX, maxX, minY, maxY;
};

vector<SalientRegion> AbstractSalientRegion(Mat map, Mat SalientImg);

#endif