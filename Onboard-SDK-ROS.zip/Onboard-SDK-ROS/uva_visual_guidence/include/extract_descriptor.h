#ifndef EXTRACT_DESCRIPTOR_Hpp
#define EXTRACT_DESCRIPTOR_Hpp

#include <opencv2/opencv.hpp>
#include <opencv2/legacy/legacy.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/features2d/features2d.hpp>

#include <opencv2/highgui/highgui.hpp>
#include <vector>
#include <iostream>

using namespace std;
using namespace cv;

Point2f getVertexCoordinateFromFile(string path, string name);
void storeMat2File(string targetFile, string str, Mat descriptor);
Mat getDescriptorFromFile(string path, string name);
vector<KeyPoint> getKeyPointFromFile(string path, string name);
string int2String(int i);
char* str2CharPt(string s);
vector<KeyPoint> extract_keypoint(Mat img, int i, string storePath, bool isStore);
Mat extract_descriptor(Mat img, vector<KeyPoint> kp, int i, string storePath, bool isStore);
void save_vertexCoordinate(Point2f vertexCoordinate, int i, string storePath);
Mat ResizeImage(Mat inputImage, double ratio);
Mat GetCenterImage(Mat src_img);
Mat rotationAndCut(Mat src_img, double yaw);
Mat rotationWithoutChangeSize(Mat src_img, float yaw);
int extract_kpdescToXML(Mat img, int i, string kpStorePath, string descStorePath, int flag, bool isStore);

#endif
