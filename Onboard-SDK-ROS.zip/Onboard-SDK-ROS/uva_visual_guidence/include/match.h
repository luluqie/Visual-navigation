#ifndef Match_H
#define Match_H

#include <opencv2/opencv.hpp>
#include <opencv2/legacy/legacy.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/highgui/highgui.hpp>

#include <vector>
#include <thread>

#include "findGPS.h"

#include "iostream"

using namespace std;
using namespace cv;

//struct Dbscan
//{
//	Point2f coordinate;
//	bool iscorePoint;
//	bool iscontained;
//	vector<int> reachable;//ֱ���ܶȿɴ�������

//};

int match(Mat img,Mat img2);
vector<Point2f> matchFromXMLFolder(Mat inputImg, float ratio);
void matchFromImgFolder(Mat inputImg, float ratio);
void showMatchedImg(Mat inputImg);
int matchAndShow(Mat img, Mat img2);
int matchFromXml(vector<KeyPoint>& keyPoint1, Mat& descriptor1, vector<KeyPoint>& keyPoint2, Mat& descriptor2);
vector<Point2f> getCentroid(vector<KeyPoint>& keyPoint1, Mat& descriptor1, vector<KeyPoint>& keyPoint2, Mat& descriptor2);
int matchedWithOrb(Mat img1, Mat img2);
int matchedWithOrbKnn();
vector<Gps> matchWithIndex(Mat img, double longitude, double latitude);
void testPartShift();
void matchedByThread(vector<KeyPoint> keyPoints_1, Mat descriptors_1, vector<matchedPic> *picSet);
Point2f matchWithIndexXML(Mat src_img, float yaw, double longitude, double latitude);
vector<Point2f> partMatchedWithOrb(vector<KeyPoint> keyPoints_1, vector<KeyPoint> keyPoints_2, Mat descriptors_1, Mat descriptors_2);

#endif
