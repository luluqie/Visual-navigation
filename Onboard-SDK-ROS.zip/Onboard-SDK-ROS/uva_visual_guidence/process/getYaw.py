import os,sys
try:
    read = open("test.txt")
    write= open("yaw.txt","w")
except IOError:
    print "the file don't exist"
    exit()
try:
    while 1:
        line=read.readline()
        if not line:
            break
        print line
     	if 'curYaw:' in line:
           write.write(line)
finally:
    read.close( )
    write.close()
