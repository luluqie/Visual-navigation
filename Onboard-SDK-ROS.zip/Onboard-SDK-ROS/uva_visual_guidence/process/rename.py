import os 
path = '/home/ubuntu/catkin_ws/src/dji_ros/Onboard-SDK-ROS/uva_visual_guidence/images/' 
i=5968
for file in os.listdir(path): 
    if os.path.isfile(os.path.join(path,file))==True: 
	if file.find('.')>0: 
	    newname=str(int(file.split('.')[0])+i)+".jpg"
	    os.rename(os.path.join(path,file),os.path.join(path,newname)) 
	    print newname 
