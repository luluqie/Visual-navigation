import os,sys
try:
    read = open("gpswithnum.txt")
    write= open("gpswithnum_1.txt","w")
except IOError:
    print "the file don't exist"
    exit()
try:
    while 1:
        line=read.readline()
        if not line:
            break
        print line.strip("\n")
	#write.write(line_lon+" "+line_lat+" "+linecache.getline("yaw.txt",j).strip('\n').strip("curYaw").strip(":")
finally:
    read.close( )
    write.close()
