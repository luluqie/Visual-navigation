import os,sys
try:
    read = open("calc.txt")
    write= open("onlinecalcgps.txt","w")
except IOError:
    print "the file don't exist"
    exit()
try:
    while 1:
        line=read.readline()
        if not line:
            break
     #   print line
        if 'longitude' in line:
            write.write(line)
     	if 'latitude' in line:
     	    write.write(line)
     #	if 'match_result.x' in line:
     #      #write.write(line.split(".x")[1])
     #	  write.write(line)
     #   if 'match_result.y' in line:
     #	  write.write(line)
     #     #write.write(line.split(".y")[1])
  
finally:
    read.close( )
    write.close()
