import os,sys
import linecache

try:
    read = open("onlinebasegps.txt")
    write= open("gpswithnum.txt","w")
    yawRead=open("yaw.txt")
except IOError:
    print "the file don't exist"
    exit()
try:
	
    i=5968 #start image number
    j=1
    while 1:
        line=read.readline()
        if not line:
            break
     	if 'latitude' in line:
	    line_lat=line.strip("\n").split(":")[1]
	if 'longitude' in line:
            line_lon=line.strip("\n").split(":")[1]
	    write.write(line_lon+" "+line_lat+" "+linecache.getline("yaw.txt",j).strip('\n').strip("curYaw").strip(":")
+" "+str(i)+"\n")
	    j=j+1
	    i=i+1
finally:
    read.close( )
    write.close()
