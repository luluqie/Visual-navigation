import os,sys
try:
    read = open("base.txt")
    write= open("onlinebasegps.txt","w")
except IOError:
    print "the file don't exist"
    exit()
try:
    while 1:
        line=read.readline()
        if not line:
            break
        print line
   #     if 'time' in line:
   #         write.write(line)
     	if 'latitude' in line:
           write.write(line)
        if 'longitude' in line:
          write.write(line)
   #     #if 'height' in line:
   #       #  write.write(line)
   #     if 'yaw' in line:
   #         write.write(line)
     #   if 'height' in line:
	#    write.write(line)
finally:
    read.close( )
    write.close()
