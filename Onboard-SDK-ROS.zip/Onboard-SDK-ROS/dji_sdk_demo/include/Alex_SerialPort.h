#ifndef _ALEX_SERIALPORT_H
#define _ALEX_SERIALPORT_H

int Alex_SerialPort_Close();
int Alex_SerialPort_BufferClear();
void ALex_SerialPort_ReadBufferSize(unsigned int *size);
int Alex_SerialPort_Send(unsigned char *buf, int len);
int Alex_SerialPort_Recv(unsigned char *buf, int len);
int Alex_SerialPort_Setup(const char *device,int baudrate);

#endif

