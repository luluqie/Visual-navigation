#ifndef TCPIP_PORT_H
#define TCPIP_PORT_H
int TCPServer_Initialize(char *ip_addr, int portno);
int TCPClient_Initialize(char* ip_addr,int portno);
int TCP_Read(int sockfd, unsigned char* buffer, int len);
int TCP_Write(int sockfd, unsigned char* buffer, int len);

int TCP_WriteChar(int sockfd,char *buffer,int len);
int TCP_ReadChar(int sockfd,char *buffer,int len);
void TCP_CloseSocket(int sockfd);
#endif // TCPIP_PORT_H
