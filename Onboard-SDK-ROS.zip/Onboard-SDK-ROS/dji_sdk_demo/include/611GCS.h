#ifndef _611GCS_H
#define _611GCS_H

unsigned int GCS_Get_time_ms();
void GCS_LinkServer();
void GCS_EndLink();
enum UAV_state_t
{
    UAV_state_onground       = 0x00,
    UAV_state_takingoff  = 0x01,
    uav_state_requestcontrolsucess      = 0x02,
    uav_state_requestcontrolfailed = 0x04,
    uav_state_reachedonewp = 0x08,
    uav_state_goingtowp = 0x0a,
    uav_state_allwpsover = 0x0b,
    uav_state_receivedwps = 0x0c,
    UAV_state_detectedlandmark        = 0x10,
    UAV_state_notdetectedlandmark     = 0x20,
    UAV_state_adjustdetectedlandmark  = 0x40,
    UAV_state_landing    = 0x80
};
extern UAV_state_t uav_state;

typedef struct _WayPoint_t
{
    double lat;
    double lon;
    double alt;
}WayPoint_t;
extern WayPoint_t  *waypoints_gcs;
extern char wp_count_gcs;
extern int wp_n;
extern bool flag_visual_guidence;                  // If true, then the waypoint navigation will be based on visual position data
extern bool cf_flag_begin;
extern float waypoint_range;

extern float takeoff_height;

enum UAV_CP_t
{
    UAV_CP_None     = 0x00,
    UAV_CP_TakeOff  = 0x01,
    UAV_CP_WayPoint = 0x02,
    UAV_CP_Land     = 0x03,
    UAV_CP_DoMarkAdjust = 0x04,
    UAV_CP_DoMarkLand   = 0x05,
    UAV_CP_DoMarkFilterTest = 0x06,
    UAV_CP_GoHome   = 0x07
};
extern UAV_CP_t UAV_CP;

extern bool RebeginFlag_MarkLand100;
extern bool RebeginFlag_MarkLand50;
extern bool flag_begin_marktest;
/* =====================================================================================
 * =====================================================================================
 * =====================================================================================
 * Send Message to GCS
 */
void GCS_TakeoffInit(void (*pp)());
void GCS_ArmInit(void (*pp)(bool ));
void GCS_RequireControlInit(void (*pp)());

/* =====================================================================================
 * =====================================================================================
 * =====================================================================================
 * Send Message to GCS
 */
void GCS_SendIdentifier();
void GCS_SendBufferInSeveralPacks(char *buffer,int send_len,int pack_len);
void GCS_SendImage(char *pic_name);
void GCS_SendGPS(int flag,double lat,double lon,double alt);
void GCS_SendLandMarkPos(float dx,float dy);
void GCS_SendStringAlt(float alt);
void GCS_SendUAVState(UAV_state_t uav_state);
void GCS_SendFlightMode(UAV_CP_t uav_cp);
void GCS_SendLoop();
/* =====================================================================================
 * =====================================================================================
 * =====================================================================================
 * Receive Message from GCS and analysis those messages.
 */
void GCS_ReceiveLoop();

/* =====================================================================================
 * =====================================================================================
 * =====================================================================================
 * Combine send and receive into one loop
 */
void GCS_LinkLoop();
int GCS_Receive_StartThread();
#endif // 611GCS_H
