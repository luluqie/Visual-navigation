#include "ros/ros.h"
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include<sensor_msgs/image_encodings.h>
#include<iostream>

//============================================================================
#include<opencv2/opencv.hpp>
#include<opencv2/highgui/highgui.hpp>
#include<opencv/cv.h>
#include <iostream>
#include <sys/time.h>
#include<stdio.h>
#include <string.h>
//============================================================================
#include<malloc.h>
#include"TCPIP_Port.h"
#include"611GCS.h"
#include<fcntl.h>

#include<unistd.h>
#include<pthread.h>
//============================================================================
using namespace std;
using namespace cv;

unsigned int Get_time(void)
{
   struct timeval cur_time;
   gettimeofday(&cur_time,NULL);
   return (cur_time.tv_sec*1000000)+(cur_time.tv_usec);
}


/*
 *
 */
void Test_ImageAndByte()
{
    int fd = open("./src/projectmap/earth.png",O_RDONLY);
    int fsize = lseek(fd,0L,SEEK_END);
    printf("The image size:%d\n",fsize);

    char imagebyte[fsize];
    FILE *fp;
    fp = fopen("./src/projectmap/earth.png","rb");
    fread(imagebyte,fsize,1,fp);
    fclose(fp);
    close(fd);

    fd = open("./src/projectmap/earth1.png",O_WRONLY | O_CREAT);
    write(fd,imagebyte,sizeof(imagebyte));
    close(fd);
}

/*
 *
 */
int sockfd;
// --------------------------------------------------
void SendBufferInSeveralPacks(char *buffer,int send_len,int pack_len)
{
    int ts = 0;
    while(send_len/pack_len > 0)
    {
        TCP_WriteChar(sockfd,buffer+ts*pack_len,pack_len);
        ++ts;
        send_len -= pack_len;
        if(ts/10 > 0)
        {
            //printf("Had transfered %d times. Now left %d\n",ts,send_len);
        }
    }
    if(send_len%pack_len > 0)
    {
        TCP_WriteChar(sockfd,buffer+ts*pack_len,send_len);
    }
}


void SendIdentifier()
{
    char *buffer="miaosuan";
    TCP_WriteChar(sockfd,buffer,8);
    printf("Send identifier.\n");
}
//int SendImage()
int SendImage(char *pic_name)
{

    //FILE *fp = fopen("./src/projectmap/earth.jpg","rb");
    //FILE *fp = fopen("./src/projectmap/earth.png","rb");
    FILE *fp = fopen(pic_name,"rb");
    if (!fp) {
        printf("read file failed!!\n");
        return 0;
    }
    else
    {
        printf("read file successed\n");
    }
    fseek(fp, 0, SEEK_END);
    int filelen = ftell(fp);
    printf("the picture length is:%d\n",filelen);
    rewind(fp);
    char *sendMessage;
    sendMessage = (char*)malloc(sizeof(char)*(filelen+15));
    memset(sendMessage,'\0', sizeof(char)*(filelen)+15);
    int count=0;
    //fread(sendMessage,filelen+1,1,fp);
    char ch;
    while (!feof(fp)) {
        ch = fgetc(fp);
        //printf("%d ",ch);
        sendMessage[count++] = ch;
    }
    sendMessage[count] = '\n';
    printf("The count is:%d\n",count);

    fclose(fp);
    int len = strlen(sendMessage);

    //TCP_WriteChar(sockfd,sendMessage,filelen+1);
    // ---------------------------------------------------------------------------------------
    // First: send head
    char headbuffer[6]={};
    headbuffer[0] = 'e';
    headbuffer[1] = 'f';
    for(int i=0;i<4;i++)
    {
        headbuffer[i+2] = filelen >> i*8;
        //printf("buffer[%x]:\n",i+2,headbuffer[i+2]);
    }
    TCP_WriteChar(sockfd,headbuffer,6);
    // ---------------------------------------------------------------------------------------
    // Second: send image package
    SendBufferInSeveralPacks(sendMessage,filelen,400);
    cout<<"Server Send one image, its size:"<<filelen<<endl;
    return 1;
}
void SendGPS(int flag,float lat,float lon,float alt)
{
    int32_t lat_t = lat*1000000;
    int32_t lon_t = lon*1000000;
    int32_t alt_t = alt*1000000;
    char gpsbuffer[20] = {};
    gpsbuffer[0] = 0xfe;
    gpsbuffer[1] = 0xff;
    int packlen = 20;
    for(int i=0;i<4;i++)
    {
        gpsbuffer[i+2] = packlen >> i*8;
        //printf("buffer[%x]:\n",i+2,headbuffer[i+2]);
    }
    gpsbuffer[6] = 0x01;
    switch(flag)
    {
    // send gps from apm
    case 1:
        gpsbuffer[7] = 0x10;
        printf("GCS Send: apm GPS data.\n");
        break;
    // send gps from visual guidance
    case 2:
        gpsbuffer[7] = 0x20;
        printf("GCS Send: visual GPS data.\n");
        break;
    // send initial gps
    case 3:
        gpsbuffer[7] = 0x60;
        printf("GCS Send: initial GPS data.\n");
        break;
    }
    int index = 8;
    for(int i=0;i<4;i++)
    {
        gpsbuffer[i+index] = lat_t >> i*8;
    }
    index = 12;
    for(int i=0;i<4;i++)
    {
        gpsbuffer[i+index] = lon_t >> i*8;
    }
    index = 16;
    for(int i=0;i<4;i++)
    {
        gpsbuffer[i+index] = alt_t >> i*8;
    }
    TCP_WriteChar(sockfd,gpsbuffer,packlen);
}



int main(int argc,char **argv)
{
    ros::init(argc,argv,"node_sendPicture");
    // --------------------------------------------------
    unsigned int time=Get_time();
    cout<<"Start connecting to Ground Control Station...."<<endl;
    cout<<"System time:"<<time<<endl;

    // Test_ImageAndByte();
    // return 0;
    // --------------------------------------------------
    /*
    //sockfd = TCPClient_Initialize("121.49.112.214",6667);
    sockfd = TCPClient_Initialize("192.168.1.182",6667);
    //sockfd = TCPClient_Initialize("192.168.1.126",6667);
    SendIdentifier();
    SendGPS(3,30.7526626+0.00003,103.9263511+0.00003,0.0);
    for(int i=1;i<10;i++)
    {
        usleep(1e4);
        char picname[30];
        sprintf(picname,"./src/projectmap/pic_test/%d.jpg",i);
        SendImage(picname);
        //SendImage();
        usleep(1e4);
        SendGPS(1,30.7526626+i*0.00003,103.9263511+i*0.00003,1.0+i);
        usleep(1e6);
    }
    TCP_CloseSocket(sockfd);
    */

    // --------------------------------------------------

    // --------------------------------------------------
    GCS_LinkServer();
    GCS_SendIdentifier();
    //GCS_ReceiveLoop();
    GCS_SendLoop();
    return 0;
}

/*
 * written by luozongqiang, use to send image
 *
#include <stdio.h>
#include <stdlib.h>
#include <String.h>
#include <winsock2.h>
#pragma comment(lib,"ws2_32.lib")
#define SERVER_PORT 6667 //侦听端口
int main()
{
    WORD wVersionRequested;
    WSADATA wsaData;
    int ret;
    SOCKET sClient; //连接套接字
    struct sockaddr_in saServer; //地址信息
    char *ptr;
    BOOL fSuccess = TRUE;

    //WinSock初始化
    wVersionRequested = MAKEWORD(2, 2); //希望使用的WinSock DLL的版本
    ret = WSAStartup(wVersionRequested, &wsaData);
    if (ret != 0)
    {
        printf("WSAStartup() failed!\n");
        return 0;
    }
    //确认WinSock DLL支持版本2.2
    if (LOBYTE(wsaData.wVersion) != 2 || HIBYTE(wsaData.wVersion) != 2)
    {
        WSACleanup();
        printf("Invalid WinSock version!\n");
        return 0;
    }

    //创建Socket,使用TCP协议
    sClient = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (sClient == INVALID_SOCKET)
    {
        WSACleanup();
        printf("socket() failed!\n");
        return 0;
    }

    //构建服务器地址信息
    saServer.sin_family = AF_INET; //地址家族
    saServer.sin_port = htons(SERVER_PORT); //注意转化为网络节序
    saServer.sin_addr.S_un.S_addr = inet_addr("121.49.112.214");

    //连接服务器
    ret = connect(sClient, (struct sockaddr *)&saServer, sizeof(saServer));
    if (ret == SOCKET_ERROR)
    {
        printf("connect() failed!\n");
        closesocket(sClient); //关闭套接字
        WSACleanup();
        return 0;
    }
    //读取本地图片传到服务端


        FILE *fp = fopen("c:\\test\\3.png","rb");
        if (!fp) {
            printf("read file failed!!");
        }
        fseek(fp, 0, SEEK_END);
        int filelen = ftell(fp);
        printf("%djj:",filelen);
        rewind(fp);
         char *sendMessage = (char*)malloc(sizeof(char)*(filelen+1));
        memset(sendMessage,'\0', sizeof(char)*(filelen));
        int count=0;
        //fread(sendMessage,filelen+1,1,fp);
        char ch;
        while (!feof(fp)) {
            ch = fgetc(fp);
            //printf("%d ",ch);
            sendMessage[count++] = ch;
        }
        sendMessage[count] = '\n';
        printf("%d ",count);

        fclose(fp);
        int len = strlen(sendMessage);
        //printf("%d ", len);
        //char s[5] = {-40,-1,-40,'f'};
        ret = send(sClient, sendMessage, filelen + 1, 0);
        if (ret == SOCKET_ERROR)
        {
            printf("send() failed!\n");
        }
        else
            printf("client info has been sent!");

        char buffer[1024];


            //int k = recv(sClient, buffer, sizeof(buffer), 0);

            //printf("%d ", k);
            //puts(buffer);

    closesocket(sClient); //关闭套接字
    WSACleanup();
    getchar();
    return 0;
}
*/
