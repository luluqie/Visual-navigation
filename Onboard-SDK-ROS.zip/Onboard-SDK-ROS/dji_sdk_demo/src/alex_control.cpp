#include <ros/ros.h>
#include <dji_sdk/dji_drone.h>
#include <cstdlib>
#include <actionlib/client/simple_action_client.h>
#include <actionlib/client/terminal_state.h>
#include <fstream>
#include <time.h>

#include <iomanip>

using namespace DJI::onboardSDK;
using namespace std;

/*

int main(int argc, char **argv)
{
    ros::init(argc,argv,"alex_control");
    ros::NodeHandle m100nh;
    DJIDrone* drone = new DJIDrone(m100nh);

    // --------------------------------------------------
    while(ros::ok())
    {
        //DJI_ReadM100();
        sleep(1);
        float roll  = atan2(2.0 * (drone->attitude_quaternion.q3 * drone->attitude_quaternion.q2 + drone->attitude_quaternion.q0 * drone->attitude_quaternion.q1) , 1.0 - 2.0 * (drone->attitude_quaternion.q1 * drone->attitude_quaternion.q1 + drone->attitude_quaternion.q2 * drone->attitude_quaternion.q2));
        float pitch = asin(2.0 * (drone->attitude_quaternion.q2 * drone->attitude_quaternion.q0 - drone->attitude_quaternion.q3 * drone->attitude_quaternion.q1));
        float yaw   = atan2(2.0 * (drone->attitude_quaternion.q3 * drone->attitude_quaternion.q0 + drone->attitude_quaternion.q1 * drone->attitude_quaternion.q2) , - 1.0 + 2.0 * (drone->attitude_quaternion.q0 * drone->attitude_quaternion.q0 + drone->attitude_quaternion.q1 * drone->attitude_quaternion.q1));
        cout<<"================>>>"<<endl;
        cout<<"roll "<<roll<<"   pitch "<<pitch<<"   yaw "<<yaw<<endl;
        ros::spinOnce();
    }
    // --------------------------------------------------
    return 0;
}
*/
// =============================================================================



#define TASK_COUNT        3   // this means how many loop you will handle

#define TASK_SEND         2
#define TASK_CONTROLDJI   1
#define TASK_REC          0
int task_hz[3] = {20,2,1};
unsigned int task_time[3] = {0,0,0};
int task_flag[3] = {0,0,0};

unsigned int GCS_Get_time_ms(void)
{
   struct timeval cur_time;
   gettimeofday(&cur_time,NULL);
   return (cur_time.tv_sec*1000)+(unsigned int)(cur_time.tv_usec/1000);
}
unsigned int time_now;

ofstream file ("/home/ubuntu/Documents/fly_data/heightlog.txt");


int main(int argc, char **argv)
{
    ros::init(argc,argv,"alex_control");
    ros::NodeHandle nh;
    DJIDrone* drone = new DJIDrone(nh);
    drone->request_sdk_permission_control();
    drone->drone_arm();
    drone->takeoff();
    /*
    sleep(3);
    drone->drone_disarm();
    sleep(3);
    sleep(3);
    drone->landing();
    */
    while(ros::ok())
    {
        // Control DJI M100
        if(task_flag[0])
        {
            //printf("This is flag control loop.\n");
            ros::spinOnce();
            //printf("The gear value:%f\n",drone->rc_channels.gear);


            task_flag[0] = 0;
        }
        // Receive msg from GCS
        if(task_flag[1])
        {
            printf("This is flag rec loop.\n");
            unsigned int t=GCS_Get_time_ms();
            file<<t<<"    "<<endl;
            task_flag[1] = 0;
        }
        // Send Data to GCS
        if(task_flag[2])
        {
            printf("This is flag send loop.\n");
            task_flag[2] = 0;
        }
        // Control loop
        time_now = GCS_Get_time_ms();
        for(int i=0;i<TASK_COUNT;++i)
        {
             if((time_now - task_time[i]) > (unsigned int)(1000/task_hz[i]))
            {
                task_flag[i] = 1;
                task_time[i] = time_now;
            }

        }

    }
    return 0;

}


// ==========================================================================
// ==========================================================================
// ==========================================================================
// *************
/* dji_sdk::GlobalPosition global_position
Header header
int32 ts
#latitude is in angle
float64 latitude
#longitude is in angle
float64 longitude
float32 altitude
float32 height
#reliablity [0,5]
int8 health
*/
// *************
/* dji_sdk::RCChannels rc_channels
Header header
int32 ts
float32 roll
float32 pitch
float32 yaw
float32 throttle
float32 mode
float32 gear

Result: higher position -10000,   lower position -4545
*/

// *************
/* dji_sdk::AttitudeQuaternion attitude_quaternion
Header header
int32 ts
# Quaternion component
float32 q0
float32 q1
float32 q2
float32 q3
# Angular speed (rad/s)
float32 wx
float32 wy
float32 wz
*/

// ==========================================================================
// ==========================================================================
// ==========================================================================


