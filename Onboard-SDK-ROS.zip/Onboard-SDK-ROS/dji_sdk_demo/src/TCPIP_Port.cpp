#include"TCPIP_Port.h"

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>

void error(const char *msg)
{
    perror(msg);
    exit(1);
}

int TCPServer_Initialize(char *ip_addr,int portno)
{
    int sockfd, newsockfd;
    socklen_t clilen;
    // serv_addr: contain the address of server
    // cli_addr: contain the address of server
    struct sockaddr_in serv_addr, cli_addr;
    //int sendBufferSize = 32*1024;
    sockfd = socket(AF_INET,SOCK_STREAM,0);

    if(sockfd<0)
    {
        error("Error opening socket.\n");
    }
    //setsockopt(sockfd,SOL_SOCKET,SO_SNDBUF,(const char*)&sendBufferSize,sizeof(int));

    bzero((char*)&serv_addr,sizeof(serv_addr));
    //portno = atoi(argv[1]);
    portno = 6000;
    serv_addr.sin_family = AF_INET;
    // sin_addr contains the IP address of machine on which server is running
    //serv_addr.sin_addr.s_addr = INADDR_ANY;

    // if you want run server and client on one machine use this
    serv_addr.sin_addr.s_addr = inet_addr(ip_addr);
    // If you want link this server on another machine, you should set the client's destination IP as below
    //serv_addr.sin_addr.s_addr = inet_addr("192.168.0.5");
    serv_addr.sin_port = htons(portno);
    if(bind(sockfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr))<0)
    {
        error("ERROR On binding\n");
    }
    listen(sockfd,5);
    clilen = sizeof(cli_addr);
    newsockfd = accept(sockfd,(struct sockaddr *)&cli_addr,
                       &clilen);
    if(newsockfd<0)
    {
        error("Error on accept\n");
    }
    printf("TCP got one client.\n");
    return newsockfd;
}
/*
 * return: client socket fd
 */
int TCPClient_Initialize(char* ip_addr,int portno)
{
    int sockfd;
    struct sockaddr_in serv_addr;

    sockfd = socket(AF_INET,SOCK_STREAM,0);
    if(sockfd<0)
    {
        error("Error opening socket\n");
    }
    serv_addr.sin_addr.s_addr = inet_addr(ip_addr);
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(portno);
    if(connect(sockfd,(struct sockaddr*)&serv_addr,sizeof(serv_addr))<0)
    {
        error("Error connecting");
    }
    printf("TCP Connected.\n");
    return sockfd;
}

int TCP_Read(int sockfd, unsigned char* buffer, int len)
{
    int n=read(sockfd,buffer,len);
    if(n<0)
    {
        error("TCP Error reading from socket.\n");
    }
    return n;
}
int TCP_Write(int sockfd, unsigned char* buffer, int len)
{
    int n = write(sockfd,buffer,len);
    if(n<0)
    {
        error("TCP Error writing to socket.\n");
    }
    return n;
}


int TCP_WriteChar(int sockfd,char *buffer,int len)
{
    int n = write(sockfd,buffer,len);
    if(n<0)
    {
        error("TCP Error writing to socket.\n");
    }
    return n;
}

int  TCP_ReadChar(int sockfd,char *buffer,int len)
{
    int n=read(sockfd,buffer,len);
    if(n<0)
    {
        error("TCP Error reading from socket.\n");
    }
    return n;
}

void TCP_CloseSocket(int sockfd)
{
    close(sockfd);
}















