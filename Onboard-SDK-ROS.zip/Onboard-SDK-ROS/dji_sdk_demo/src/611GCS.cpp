#include "../include/611GCS.h"
#include "../include/TCPIP_Port.h"
#include "../include/Alex_SerialPort.h"


#include <sys/time.h>
#include <iostream>
#include <pthread.h>
#include <unistd.h>
#include <stdio.h>
#include <malloc.h>
#include <fcntl.h>
#include <string.h>
#include <iomanip>
using namespace std;

// If you want use serial link, uncomment this line
#define DEBUG_SERIAL_LINK
UAV_state_t uav_state = UAV_state_onground;
WayPoint_t *waypoints_gcs = (WayPoint_t*)malloc(sizeof(WayPoint_t)*(3));
char wp_count_gcs = 0;
int wp_n = 0;

float takeoff_height = 253.0;

UAV_CP_t UAV_CP = UAV_CP_None;
bool RebeginFlag_MarkLand100 = false;
bool RebeginFlag_MarkLand50 = false;

bool flag_begin_marktest = false;
bool flag_visual_guidence = false;
bool cf_flag_begin = false;
float waypoint_range = 5;
/* =====================================================================================
 * =====================================================================================
 * =====================================================================================
 * Callback Methods
 */
void (*ptr_takeoff)();
void GCS_TakeoffInit(void (*pp)())
{
    ptr_takeoff = pp;
}
void GCS_TakeOff()
{
    (*ptr_takeoff)();
}

void (*ptr_arm)(bool );
void GCS_ArmInit(void (*pp)(bool ))
{
    ptr_arm = pp;
}
void GCS_Arm(bool flag)
{
    (*ptr_arm)(flag);
}

void (*ptr_requirecontrol)();
void GCS_RequireControlInit(void (*pp)())
{
    ptr_requirecontrol = pp;
}
void GCS_RequireControl()
{
    (*ptr_requirecontrol)();
}

/* =====================================================================================
 * =====================================================================================
 * =====================================================================================
 * Common Methods
 */
unsigned int GCS_Get_time_ms()
{
   struct timeval cur_time;
   gettimeofday(&cur_time,NULL);
   return (cur_time.tv_sec*1000)+(unsigned int)(cur_time.tv_usec/1000);
}

int chars2int(char *buffer)
{
    int res;
    res = (int)(buffer[3]<<24 | buffer[2]<<16 | buffer[1]<<8 | buffer[0]);
    printf("buffer[0]:%x, buffer[1]:%x, buffer[2]:%x, buffer[3]:%x\n",
           buffer[0],buffer[1],buffer[2],buffer[3]);
    return res;
}


char *sendMessage;
void GCS_InitializImageBuffer()
{
    sendMessage = (char*)malloc(sizeof(char)*(500000));
}
void GCS_FreeImageBuffer()
{
    free(sendMessage);
}


int gcs_fd;
void GCS_LinkServer()
{
    GCS_InitializImageBuffer();
    #ifdef DEBUG_SERIAL_LINK
    Alex_SerialPort_Setup("/dev/ttyUSB0",57600);
    #else
    gcs_fd = TCPClient_Initialize("121.49.115.245",6667);
    #endif
}
void GCS_EndLink()
{
    GCS_FreeImageBuffer();
    #ifdef DEBUG_SERIAL_LINK
    Alex_SerialPort_Close();
    #else
    TCP_CloseSocket(gcs_fd);
    #endif
}

/* =====================================================================================
 * =====================================================================================
 * =====================================================================================
 * Send Message to GCS
 */
/*
 * Send Identifier to let Aliyun server know this is miaosuan from apm
 */
void GCS_SendIdentifier()
{
    char *buffer="miaosuan";
    #ifdef DEBUG_SERIAL_LINK
    Alex_SerialPort_Send((unsigned char *)buffer,8);
    #else
    TCP_WriteChar(gcs_fd,buffer,8);
    #endif
    printf("Send identifier.\n");
}

/*
 * Send A large buffer in several times
 * pack_len: how many bytes sended at one time
 */
void GCS_SendBufferInSeveralPacks(char *buffer,int send_len,int pack_len)
{
    int ts = 0;
    while(send_len/pack_len > 0)
    {
        TCP_WriteChar(gcs_fd,buffer+ts*pack_len,pack_len);
        ++ts;
        send_len -= pack_len;
        if(ts/10 > 0)
        {
            //printf("Had transfered %d times. Now left %d\n",ts,send_len);
        }
    }
    if(send_len%pack_len > 0)
    {
        TCP_WriteChar(gcs_fd,buffer+ts*pack_len,send_len);
    }
}
/*
 * Send an image to GCS.
 */

void GCS_SendImage(char *pic_name)
{
    //FILE *fp = fopen("./src/projectmap/earth.jpg","rb");
    //FILE *fp = fopen("./src/projectmap/earth.png","rb");
    FILE *fp = fopen(pic_name,"rb");
    if (!fp) {
        printf("read file failed!!\n");
        return;
    }
    else
    {
        //printf("read file successed\n");
    }
    fseek(fp, 0, SEEK_END);
    int filelen = ftell(fp);
    //printf("the picture length is:%d\n",filelen);
    rewind(fp);
    //ndMessage = (char*)malloc(sizeof(char)*(filelen+15));
    memset(sendMessage,'\0', sizeof(char)*(filelen)+15);
    int count=0;
    //fread(sendMessage,filelen+1,1,fp);
    char ch;
    while (!feof(fp)) {
        ch = fgetc(fp);
        //printf("%d ",ch);
        sendMessage[count++] = ch;
    }
    sendMessage[count] = '\n';
    //printf("The count is:%d\n",count);

    fclose(fp);
    int len = strlen(sendMessage);

    //TCP_WriteChar(sockfd,sendMessage,filelen+1);
    // ---------------------------------------------------------------------------------------
    // First: send head
    int pack_len = filelen + 2;
    char headbuffer[8]={};
    headbuffer[0] = 0xfe;
    headbuffer[1] = 0xff;
    for(int i=0;i<4;i++)
    {
        headbuffer[i+2] = pack_len >> i*8;
        //printf("buffer[%x]:\n",i+2,headbuffer[i+2]);
    }
    headbuffer[6] = 0x01;
    headbuffer[7] = 0x50;
    // ---------------------------------------------------------------------------------------
    // Second: send image package
    #ifdef DEBUG_SERIAL_LINK
    Alex_SerialPort_Send((unsigned char*)headbuffer,8);
    Alex_SerialPort_Send((unsigned char*)sendMessage,filelen);
    #else
    TCP_WriteChar(gcs_fd,headbuffer,8);
    GCS_SendBufferInSeveralPacks(sendMessage,filelen,400);
    #endif
    //printf("Server Send one image, its size:%d\n",filelen);
    //return 1;
}
/* If flag = 3: send the initial gps
 * If flag = 2: send the gps from visual guidance
 * If flag = 1: send the gps from apm
 */
void GCS_SendGPS(int flag,double lat,double lon,double alt)
{
    uint32_t lat_t = lat*1000000;
    uint32_t lon_t = lon*1000000;
    uint32_t alt_t = alt*1000000;
    //#ifdef DEBUG_SERIAL_LINK
    //unsigned char gpsbuffer[20]={};
    //#else
    char gpsbuffer[20] = {};
    //#endif
    gpsbuffer[0] = 0xfe;
    gpsbuffer[1] = 0xff;
    int packlen = 20;
    for(int i=0;i<4;i++)
    {
        gpsbuffer[i+2] = (packlen-6) >> i*8;
        //printf("buffer[%x]:\n",i+2,headbuffer[i+2]);
    }
    gpsbuffer[6] = 0x01;
    switch(flag)
    {
    // send gps from apm
    case 1:
        gpsbuffer[7] = 0x10;
        //printf("GCS Send: apm GPS data.\n");
        break;
    // send gps from visual guidance
    case 2:
        gpsbuffer[7] = 0x70;
        //printf("GCS Send: visual GPS data.\n");
        break;
    // send initial gps
    case 3:
        gpsbuffer[7] = 0x60;
        //printf("GCS Send: initial GPS data.\n");
        break;
    }
    int index = 8;
    for(int i=0;i<4;i++)
    {
        gpsbuffer[i+index] = lat_t >> i*8;
    }
    index = 12;
    for(int i=0;i<4;i++)
    {
        gpsbuffer[i+index] = lon_t >> i*8;
    }
    index = 16;
    for(int i=0;i<4;i++)
    {
        gpsbuffer[i+index] = alt_t >> i*8;
    }
    #ifdef DEBUG_SERIAL_LINK
    Alex_SerialPort_Send((unsigned char*)gpsbuffer,packlen);
    //unsigned char buf[] = "hello world\n";
    //Alex_SerialPort_Send(buf,12);
    #else
    TCP_WriteChar(gcs_fd,gpsbuffer,packlen);
    #endif
}

void GCS_SendUAVState(UAV_state_t uav_state)
{
    char statebuffer[9] = {};
    statebuffer[0] = 0xfe;
    statebuffer[1] = 0xff;
    int packlen = 9;
    for(int i=0;i<4;i++)
    {
        statebuffer[i+2] = (packlen-6) >> i*8;
        //printf("buffer[%x]:\n",i+2,headbuffer[i+2]);
    }
    statebuffer[6] = 0x01;
    statebuffer[7] = 0x20;
    statebuffer[8] = (char)uav_state;
    #ifdef DEBUG_SERIAL_LINK
    Alex_SerialPort_Send((unsigned char*)statebuffer,packlen);
    #else
    TCP_WriteChar(gcs_fd,statebuffer,packlen);
    #endif
}
void GCS_SendFlightMode(UAV_CP_t uav_cp)
{
    char modebuffer[9] = {};
    modebuffer[0] = 0xfe;
    modebuffer[1] = 0xff;
    int packlen = 9;
    for(int i=0;i<4;i++)
    {
        modebuffer[i+2] = (packlen-6) >> i*8;
        //printf("buffer[%x]:\n",i+2,headbuffer[i+2]);
    }
    modebuffer[6] = 0x01;
    modebuffer[7] = 0x30;
    modebuffer[8] = (char)uav_cp;
    #ifdef DEBUG_SERIAL_LINK
    Alex_SerialPort_Send((unsigned char*)modebuffer,packlen);
    #else
    TCP_WriteChar(gcs_fd,modebuffer,packlen);
    #endif

}
// Used for test
void GCS_SendStringAlt(float alt)
{
    char str[30];
    sprintf(str,"%f\n",alt);
    TCP_WriteChar(gcs_fd,str,30);
}
void GCS_SendLandMarkPos(float dx,float dy)
{
    int32_t body_dx = dx*10;
    int32_t body_dy = dy*10;
    //#ifdef DEBUG_SERIAL_LINK
    //unsigned char gpsbuffer[20]={};
    //#else
    char markbuffer[16] = {};
    //#endif
    markbuffer[0] = 0xfe;
    markbuffer[1] = 0xff;
    int packlen = 16;
    for(int i=0;i<4;i++)
    {
        markbuffer[i+2] = (packlen-6) >> i*8;
        //printf("buffer[%x]:\n",i+2,headbuffer[i+2]);
    }
    markbuffer[6] = 0x01;
    markbuffer[7] = 0x80;
    int index = 8;
    for(int i=0;i<4;i++)
    {
        markbuffer[i+index] = body_dx >> i*8;
    }
    index = 12;
    for(int i=0;i<4;i++)
    {
        markbuffer[i+index] = body_dy >> i*8;
    }
    #ifdef DEBUG_SERIAL_LINK
    Alex_SerialPort_Send((unsigned char*)markbuffer,packlen);
    //unsigned char buf[] = "hello world\n";
    //Alex_SerialPort_Send(buf,12);
    #else
    TCP_WriteChar(gcs_fd,gpsbuffer,packlen);
    #endif
    //printf("[Debug] land marker\n");
}
void GCS_SendLoop()
{
    for(int i=1;i<10;++i)
    {
        GCS_SendUAVState(UAV_state_takingoff);
        sleep(1);
        //GCS_SendUAVState(UAV_state_onrtl);
        sleep(1);
        //GCS_SendUAVState(UAV_state_onwaypoint);
        sleep(1);
        GCS_SendUAVState(UAV_state_adjustdetectedlandmark);
        sleep(1);
    }

}
/* =====================================================================================
 * =====================================================================================
 * =====================================================================================
 * Receive Message from GCS and analysis those messages.
 */
// ------------------------------------------------------------------------------------
// receive the waypoints
void GCS_PackageAnalysisWP(char *packbuffer)
{

//ofstream log_gcs_file("/home/ubuntu/Documents/fly_data/alex_gcs_log.txt");
    char points_num = packbuffer[0];
    //log_gcs_file<<"Time ms: "<<GCS_Get_time_ms()<<endl;
    printf("GCS Rec: GPS points: %d\n",points_num);
    free(waypoints_gcs);
    wp_count_gcs = points_num;
    //log_gcs_file<<"     wp num: "<<wp_count_gcs<<endl;
    waypoints_gcs = (WayPoint_t*)malloc(sizeof(WayPoint_t)*(points_num));
    uint32_t lat = 0;
    uint32_t lon = 0;
    int32_t alt = 0;
    int index = 1;
    for(int i=0;i<points_num;++i)
    {
        lat = (uint32_t)(packbuffer[index+i*12+3]<<24 | packbuffer[index+i*12+2]<<16 | packbuffer[index+i*12+1]<<8 |packbuffer[index+i*12+0]);
        lon = (uint32_t)(packbuffer[index+i*12+7]<<24 | packbuffer[index+i*12+6]<<16 | packbuffer[index+i*12+5]<<8 |packbuffer[index+i*12+4]);
        alt = (int32_t)(packbuffer[index+i*12+11]<<24 | packbuffer[index+i*12+10]<<16 | packbuffer[index+i*12+9]<<8 |packbuffer[index+i*12+8]);
        printf("GCS Rec: GPS point %d, lat %d,lon %d,alt %d\n",i,lat,lon,alt);
        waypoints_gcs[i].lat = (double)(lat/1e6);
        waypoints_gcs[i].lon = (double)(lon/1e6);
        waypoints_gcs[i].alt = (double)(alt/1e3);
        //log_gcs_file<<"     wp: "<<i<<setiosflags(ios::fixed)<<setprecision(6)<<"lat: "<<waypoints_gcs[i].lat<<"lon: "<<waypoints_gcs[i].lon<<endl;
    }
    uav_state = uav_state_receivedwps;
}
// ------------------------------------------------------------------------------------
void GCS_MissionRebegin()
{
    RebeginFlag_MarkLand50 = true;
    cf_flag_begin = false;
}
void GCS_PackageControlMsg(char ctlmsg)
{
    switch(ctlmsg)
    {
    case 0x00:
        printf("GCS_Rec: rebegin.\n");
        UAV_CP = UAV_CP_TakeOff;
        uav_state = UAV_state_onground;
        GCS_MissionRebegin();
        wp_n = 0;
    break;
    case 0xa0:
        printf("GCS Rec: arm.\n");
        (*GCS_Arm)(true);
        break;
    case 0xa1:
        printf("GCS Rec: disarm\n");
        (*GCS_Arm)(false);
        break;
    case 0xb0:
        printf("GCS Rec: obtain control.\n");
        (*GCS_RequireControl)();
        break;
    case 0xc0:
        printf("GCS Rec: waypoint use visual guidence control.\n");
        cf_flag_begin = false;
        flag_visual_guidence = true;
        waypoint_range = 30;
        break;
    case 0xc1:
        printf("GCS Rec: waypoint use gps guidence control.\n");
        flag_visual_guidence = false;
        waypoint_range = 5;
        break;
    case 0xd0:
        printf("GCS Rec: Do Mark Filter Test\n");
        flag_begin_marktest = false;
        UAV_CP = UAV_CP_DoMarkFilterTest;
        break;
    case 0xe0:
        printf("GCS Rec: Do Mark Ajdust.\n");
        UAV_CP = UAV_CP_DoMarkAdjust;
        break;
    case 0xf0:
        printf("GCS Rec: Do Mark Land.\n");
        UAV_CP = UAV_CP_DoMarkLand;
        RebeginFlag_MarkLand100 = true;
        RebeginFlag_MarkLand50 = false;
        break;
    case 0xf1:
        printf("GCS Rec: Do Mark Land.\n");
        UAV_CP = UAV_CP_DoMarkLand;
        RebeginFlag_MarkLand50 = true;
        RebeginFlag_MarkLand100 = false;
        break;
    case 0xa2:
        printf("GCS Rec: Go Home.\n");
        waypoint_range = 5;
        flag_visual_guidence = false;
        UAV_CP = UAV_CP_GoHome;
        break;
    default:
        printf("GCS Rec: unknow control %x\n",ctlmsg);
        break;
    }
}
// ------------------------------------------------------------------------------------
void GCS_PackageAnalysisHeight(char *packbuffer)
{
    int32_t height = (int32_t)(packbuffer[3]<<24 | packbuffer[2]<<16 | packbuffer[1]<<8 |packbuffer[0]);
    takeoff_height = (float)height/1e3;
    printf(" %f m\n",takeoff_height);
}
// ------------------------------------------------------------------------------------
void GCS_MessageAnalysis(char* msgbuffer)
{
    char iden1 = msgbuffer[0];
    char iden2 = msgbuffer[1];
    switch(iden1)
    {
    case 0x02:
        switch(iden2)
        {
        case 0x10:
            printf("The control message:%x\n",msgbuffer[2]);
            GCS_PackageControlMsg(msgbuffer[2]);
            break;
        case 0x30:
            printf("The way points:\n");
            GCS_PackageAnalysisWP(msgbuffer+2);
            break;
        case 0x40:
            printf("The height:");
            GCS_PackageAnalysisHeight(msgbuffer+2);
            break;
        }
        break;
    default:
        printf("GCS Rec: error message\n");
        break;
    }
}

void GCS_ReceiveLoop()
{
    #ifdef DEBUG_SERIAL_LINK
    unsigned char msg_head = 0x00;
    unsigned char msg_length[4] = {0x00,0x00,0x00,0x00};
    int msg_len = 0;
    unsigned int t1 = GCS_Get_time_ms();
    unsigned int size;
    ALex_SerialPort_ReadBufferSize(&size);
    if(size<=0)
        return;
    int num = Alex_SerialPort_Recv(&msg_head,1);
    if(num>0)
    {
        //printf("GCS Rec: the head %c, %x, %d\n",msg_head_u,msg_head_u,msg_head_u);
        //printf("GCS Rec: the head %c, %x, %d\n",(char)msg_head,(char)msg_head,(char)msg_head);
    }
    if(0xfe == (char)msg_head)
    {
        Alex_SerialPort_Recv(&msg_head,1);
        if(0xff == (char)msg_head)
        {
            //printf("GCS Rec: Received one message\n");
            Alex_SerialPort_Recv(msg_length,4);
            msg_len = (int)(msg_length[3]<<24 | msg_length[2]<<16 | msg_length[1]<<8 | msg_length[0]);
            //printf("GCS Rec: the message length is :%d\n",msg_len);
            if(msg_len > 0)
            {
                unsigned char* msg_buffer = (unsigned char*)malloc(msg_len);
                Alex_SerialPort_Recv(msg_buffer,msg_len);
                GCS_MessageAnalysis((char*)msg_buffer);
                free(msg_buffer);
            }
        }
    }

    // If you want use TCPIP to transfer data then use this
    #else

    char msg_head = 0x00;
    unsigned char msg_head_u = 0x00;
    char msg_length[4] = {0x00,0x00,0x00,0x00};
    int msg_len = 0;
    unsigned int t1 = GCS_Get_time_ms();
    //while(1)
    //{
        //int num = TCP_Read(gcs_fd,&msg_head_u,1);

        int num = TCP_ReadChar(gcs_fd,&msg_head,1);
        if(num>0)
        {
            //printf("GCS Rec: the head %c, %x, %d\n",msg_head_u,msg_head_u,msg_head_u);
            printf("GCS Rec: the head %c, %x, %d\n",msg_head,msg_head,msg_head);
        }
        if(0xfe == msg_head)
        {
            TCP_ReadChar(gcs_fd,&msg_head,1);
            if(0xff == msg_head)
            {
                //printf("GCS Rec: Received one message\n");
                TCP_ReadChar(gcs_fd,msg_length,4);
                msg_len = (int)(msg_length[3]<<24 | msg_length[2]<<16 | msg_length[1]<<8 | msg_length[0]);
                printf("GCS Rec: the message length is :%d\n",msg_len);
                if(msg_len > 0)
                {
                    char* msg_buffer = (char*)malloc(msg_len);
                    TCP_ReadChar(gcs_fd,msg_buffer,msg_len);
                    GCS_MessageAnalysis(msg_buffer);
                }
            }
        }
    #endif
        //
    //}
}
// ------------------------------------------------------------------------------------



/*
 * Phtread don't work in ROS
 */
void *GCS_Receive_ThreadFun(void *arg)
{
    char msg_head = 0x00;
    char msg_length[4] = {0x00,0x00,0x00,0x00};
    u_int32_t msg_len = 0;
    while(1)
    {
        printf("hhhh.\n");
        sleep(1);
        TCP_ReadChar(gcs_fd,&msg_head,1);
        if(0xfe == msg_head)
        {
            TCP_ReadChar(gcs_fd,&msg_head,1);
            if(0xff == msg_head)
            {
                printf("GCS Rec: Received one message\n");
                TCP_ReadChar(gcs_fd,msg_length,4);
                msg_len = (u_int32_t)(msg_length[3]<<24 | msg_length[2]<<16 | msg_length[1]<<8 | msg_length[0]);
                printf("GCS Rec: the message length is :%d\n",msg_len);
                if(msg_len > 0)
                {
                    char* msg_buffer = (char*)malloc(msg_len);
                    TCP_ReadChar(gcs_fd,msg_buffer,msg_len);
                    GCS_MessageAnalysis(msg_buffer);
                }
            }
        }
    }
}

int GCS_Receive_StartThread()
{
    int ret;
    pthread_t gcs_thread;
    ret = pthread_create(&gcs_thread,NULL,GCS_Receive_ThreadFun,NULL);
    if(ret != 0)
    {
        printf("Create thread failed.\n");
        return 0;
    }
    return 1;
}
