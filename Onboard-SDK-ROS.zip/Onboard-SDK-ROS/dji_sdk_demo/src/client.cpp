#include <ros/ros.h>
#include <dji_sdk/dji_drone.h>
#include <cstdlib>
#include <actionlib/
/simple_action_client.h>
#include <actionlib/client/terminal_state.h>
#include <fstream>
#include <time.h>
#include <math.h>
#include <iomanip>

//============================================================================
#include <iostream>
#include <sys/time.h>
#include<stdio.h>
#include <string.h>
#include <malloc.h>
#include "../include/TCPIP_Port.h"
#include "../include/611GCS.h"

#include<unistd.h>
//#include<fcntl.h>
//#include<pthread.h>
//============================================================================
#define LINK_VISUAL_MSG
#ifdef LINK_VISUAL_MSG
#include "dji_sdk_demo/dji_info.h"      //msg中的.msg
#include "dji_sdk_demo/landmark_info.h" //msg中的.msg
#endif // LINK_DJI_SDK

#define DEBUG_DJI_SDK
#define DEBUG_GCS_LINK     // if you want this node link GCS uncomment this line

using namespace std;
using namespace DJI::onboardSDK;

ofstream file("/home/ubuntu/Documents/fly_data/alex_client_log.txt");
// used to store the log data about position adjusting with land mark
ofstream mark_file("/home/ubuntu/Documents/fly_data/alex_client_markDebuglog.txt");
ofstream mark_land_file("/home/ubuntu/catkin_ws/src/dji_ros/Onboard-SDK-ROS/dji_sdk_demo/AlexLog/markland.txt");
ofstream navigation_file("/home/ubuntu/catkin_ws/src/dji_ros/Onboard-SDK-ROS/dji_sdk_demo/AlexLog/navigation.txt");
ofstream file_test("/home/ubuntu/catkin_ws/src/dji_ros/Onboard-SDK-ROS/dji_sdk_demo/AlexLog/test_nav.txt");
ofstream waypoint_nav("/home/ubuntu/catkin_ws/src/dji_ros/Onboard-SDK-ROS/dji_sdk_demo/AlexLog/waypoint_nav.txt");
DJIDrone* drone;
bool flag_incontrol = false;
// divide control process into several parts
float Rbe11 = 0;
float Rbe12 = 0;
float Rbe13 = 0;
float Rbe21 = 0;
float Rbe22 = 0;
float Rbe23 = 0;
float Rbe31 = 0;
float Rbe32 = 0;
float Rbe33 = 0;

float dji_globalvelx = 0.0;
float dji_globalvely = 0.0;
float dji_globalvelz = 0.0;
float dji_bodyvelx = 0.0;
float dji_bodyvely = 0.0;
float dji_bodyvelz = 0.0;

double dji_gps_lat = 0;
double dji_gps_lon = 0;
double dji_gps_alt = 99.9;
// ------------------------------------------------------------------------------
double visual_gps_lat = 999.9;
double visual_gps_lon = 999.9;
// complementary Filter: fuse Visual Position and DJI velocity to get a better position

// the ratio relate meter with gps
float cf_ratio_lat = 0.898e-5;      // 1 m = 0.898e-5 gps ; 1e-5 gps = 1.113m;
float cf_ratio_lon = 0.682e-5;      // 1 m = 0.682e-5 gps ; 1e-5 gps = 1.467m;
float cf_KP = 0.8;
double cf_gps_lat = 0.0;
double cf_gps_lon = 0.0;
// ------------------------------------------------------------------------------
// nonlinear complementary filter's kp when landing
#define  KP_MARK       0.8
float landmark_dx = 0.0;
float landmark_dy = -0.0;
float landmark_ratio = 0.0;
float filter_landmark_dx = 0.0;
float filter_landmark_dy = 0.0;

// ------------------------------------------------------------------------------
float dji_gear = -5000;
float yaw;

//For testing: used for waypoints navigation test
WayPoint_t cur_point;
WayPoint_t home_point;

int wp_count = 3;
WayPoint_t waypoints[3] = {{30.7485024,103.9241409,260},{30.7485762,103.9238298,260},{30.7488344,103.9240873,260}};

// ------------------------------------------------------------------------------
void DJI_SDK_Loop(DJIDrone* drone);//通过DJI SDK更新获取飞机的飞行数据如GPS位置、速度、遥控器拨动开关的位置等
float DJI_TakeOff(DJIDrone* drone,float des_alt);//让飞机起飞至指定飞行高度
float Alex_VelControlWayPoint(DJIDrone* drone,WayPoint_t des_point);
bool Alex_WayPoint(DJIDrone* drone,int wp_num,WayPoint_t *wps);//飞机执行巡点任务，根据GCS发送的航点，控制飞机依次到达这些航点

void Alex_EulerControl(DJIDrone* drone,WayPoint_t des_point);
float Alex_VelControlLandMark(DJIDrone* drone);
void Alex_Land(DJIDrone* drone);//根据地面降落标志进行导航降落，降落分为重复的两个阶段即下降到指定调整高度和在指定调整高度调整飞机的水平位置。指定高度分为三个高度：100m，50m，20m，可根据实际环境情况选择第一个调整高度是100m还是50m，这个可由参数RebeginFlag_MarkLand100和RebeginFlag_MarkLand50的赋值来确定。同时这个参数可由地面站发送控制指令进行更改。
void Alex_Land_SimuTest(DJIDrone* drone);
void Alex_MarkFilterTest(DJIDrone* drone);
void Alex_RemoterControl(DJIDrone* drone);//当遥控器拨动开关处于下方位置是，这个函数用来根据读取到的遥杆状态量来通过SDK控制飞机。

#ifdef LINK_VISUAL_MSG
void DJI_visual_gps_Callback(const dji_sdk_demo::dji_info& msg)
{
    visual_gps_lat = msg.lat;
    visual_gps_lon = msg.lon;
    //cout<<setiosflags(ios::fixed)<<setprecision(6)<<"Current visual gps lat:"<<msg.lat<<" lon:"<<msg.lon<<endl;
    //printf("Current visual gps:%.5f,,%.5f",visual_gps_lat,visual_gps_lon);
    if(!cf_flag_begin)
    {
        cf_flag_begin = true;
        cf_gps_lat = visual_gps_lat;
        cf_gps_lon = visual_gps_lon;
        navigation_file<<"Initialized GPS position: lat-> "<<setiosflags(ios::fixed)<<setprecision(6)<<cf_gps_lat<<" lon->"<<cf_gps_lon<<endl;
    }
    else
    {
        navigation_file<<"Before filter GPS position: lat-> "<<setiosflags(ios::fixed)<<setprecision(6)<<cf_gps_lat<<" lon->"<<cf_gps_lon<<endl;
        // ====================================================================================
        // complementary filter
        cf_gps_lat = cf_KP*visual_gps_lat + (1-cf_KP)*cf_gps_lat;
        cf_gps_lon = cf_KP*visual_gps_lon + (1-cf_KP)*cf_gps_lon;
        // ====================================================================================
        navigation_file<<"After filter GPS position: lat-> "<<setiosflags(ios::fixed)<<setprecision(6)<<cf_gps_lat<<" lon->"<<cf_gps_lon<<endl;
    }
}

void LandMark_Info_Callback(const dji_sdk_demo::landmark_info& msg)
{
    landmark_dx = msg.dx;
    landmark_dy = msg.dy;
    landmark_ratio = msg.h_ratio;
    //printf("[CallBack] landmark: dx->%f, dy->%f, ratio->%f\n",msg.dx,msg.dy,msg.h_ratio);
    mark_file<<"Land mark: dx->"<<setiosflags(ios::fixed)<<setprecision(6)<<landmark_dx<<"  dy->"<<landmark_dy<<"  ratio->"<<landmark_ratio<<endl;
    mark_file<<"before: filter_dx->"<<filter_landmark_dx<<"  filter_dy->"<<filter_landmark_dy<<endl;
    // use filter to fuse a new position

    if(UAV_CP == UAV_CP_DoMarkFilterTest)
    {
        if(!flag_begin_marktest)
        {
            if(fabs(landmark_dx)>0.01 && fabs(landmark_dy)>0.01 && landmark_ratio > 0)
            {
                filter_landmark_dx = landmark_dx*landmark_ratio;
                filter_landmark_dy = landmark_dy*landmark_ratio;
                flag_begin_marktest = true;
                mark_file<<"Initialized Postion>"<<endl;
            }
            return;
        }
        if(fabs(landmark_dx)>0.01 && fabs(landmark_dy)>0.01 && landmark_ratio > 0)
        {
            filter_landmark_dx = KP_MARK*landmark_dx*landmark_ratio + (1-KP_MARK)*filter_landmark_dx;
            filter_landmark_dy = KP_MARK*landmark_dy*landmark_ratio + (1-KP_MARK)*filter_landmark_dy;
            mark_file<<"after: filter_dx->"<<filter_landmark_dx<<"  filter_dy->"<<filter_landmark_dy<<endl;
        }
    }
    else
    {
        if(fabs(filter_landmark_dx - landmark_dx*landmark_ratio)<10 && fabs(filter_landmark_dy - landmark_dy*landmark_ratio)<10)
        {
            if(fabs(landmark_dx)>0.01 && fabs(landmark_dy)>0.01 && landmark_ratio > 0)
            {
                filter_landmark_dx = KP_MARK*landmark_dx*landmark_ratio + (1-KP_MARK)*filter_landmark_dx;
                filter_landmark_dy = KP_MARK*landmark_dy*landmark_ratio + (1-KP_MARK)*filter_landmark_dy;
                mark_file<<"after: filter_dx->"<<filter_landmark_dx<<"  filter_dy->"<<filter_landmark_dy<<endl;
            }
        }
        else
        {
            mark_file<<"large error detected"<<endl;
        }
    }
    mark_file<<"CallBack time: "<<GCS_Get_time_ms()<<endl;
}
#endif
// =============================================================================
void Alex_RequireControl()
{
    bool flag_tmp = drone->request_sdk_permission_control();
    if(flag_tmp)
    {
        flag_incontrol = true;
        uav_state = uav_state_requestcontrolsucess;
    }
    else
    {
        uav_state = uav_state_requestcontrolfailed;
    }
    if(flag_incontrol)
    {
        printf("[Debug] Client: request control success\n");
    }
    else
    {
        printf("[Debug] Client: request control failed\n");
    }
}
void Alex_Arm(bool armdisarm)
{
    if(armdisarm)
    {
        home_point.lat = dji_gps_lat;
        home_point.lon = dji_gps_lon;
        home_point.alt = dji_gps_alt;
        if(drone->drone_arm())
        {
            printf("[Debug] arm sucess\n");

        }
        else
        {
            printf("[Debug] arm failed\n");
        }
    }
    else
    {
        if(drone->drone_disarm())
        {
            printf("[Debug] disarm sucess\n");
        }
        else
        {
            printf("[Debug] disarm failed\n");
        }
    }
}
//============================================================================
#define TASK_COUNT        4   // this means how many loop you will handle

#define TASK_CONTROLDJI   0
#define TASK_REC          1
#define TASK_SEND_1HZ     2
#define TASK_SEND_5HZ     3
int task_hz[] = {50,5,1,5};
unsigned int task_time[] = {0,0,0,0};
int task_flag[] = {0,0,0,0};
unsigned int time_now;

// =============================================================================

int main(int argc, char **argv)
{
    ros::init(argc,argv,"client");
    ros::NodeHandle m100nh;
    drone = new DJIDrone(m100nh);
    // --------------------------------------------------
    // callback initialize
    GCS_RequireControlInit(Alex_RequireControl);
    GCS_ArmInit(Alex_Arm);
    // --------------------------------------------------
    unsigned int time=GCS_Get_time_ms();
    cout<<"Start connecting to Ground Control Station...."<<endl;
    cout<<"System time:"<<time<<endl;
    float lat_init = 30.7527;
    float lon_init = 103.9262;

    // --------------------------------------------------
#ifdef LINK_VISUAL_MSG
    ros::NodeHandle visual_gps_node;
    ros::Subscriber visual_gps_sub = visual_gps_node.subscribe("visual_gps",10,DJI_visual_gps_Callback);
    ros::NodeHandle landmark_node;
    ros::Subscriber landmark_sub = landmark_node.subscribe("landmark_info",10,LandMark_Info_Callback);
#endif
    // --------------------------------------------------

    // --------------------------------------------------
    // The picture location
    char picname[] = "/home/ubuntu/catkin_ws/src/dji_ros/Onboard-SDK-ROS/uva_visual_guidence/image_gcs/img_dji.jpg";
#ifdef DEBUG_GCS_LINK
    GCS_LinkServer();
    GCS_SendIdentifier();
#endif // DEBUG_GCS_LINK
    // --------------------------------------------------
    //
    int cnt_send = 0;
    WayPoint_t des_point = {30.7486329,103.9247383,100};
    // --------------------------------------------------
    // Initilize the variables
    uav_state = UAV_state_onground;
    UAV_CP = UAV_CP_TakeOff;
    //UAV_CP = UAV_CP_DoMarkFilterTest;
    flag_visual_guidence = true;
    if(flag_visual_guidence)
    {
        waypoint_range = 30;
    }
    else
    {
        waypoint_range = 5;
    }
    RebeginFlag_MarkLand100 = true;
    RebeginFlag_MarkLand50 = false;
    sleep(3);
    while(ros::ok())
    {
        // Control DJI M100
        if(task_flag[0])
        {
            //printf("This is flag control loop.\n");
            ros::spinOnce();
            DJI_SDK_Loop(drone);
            // You need control authority first.
            if(flag_incontrol)
            {
                if(-10000 == dji_gear)
                {
                    switch(UAV_CP)
                    {
                    case UAV_CP_TakeOff:
                        if(DJI_TakeOff(drone,takeoff_height)<2)
                        {
                            UAV_CP = UAV_CP_WayPoint;
                        }
                        uav_state = UAV_state_takingoff;
                        break;
                    case  UAV_CP_WayPoint:
                        //if(Alex_WayPoint(drone,wp_count,waypoints))  //
                        if(Alex_WayPoint(drone,(int)wp_count_gcs,waypoints_gcs))
                        {
                            UAV_CP = UAV_CP_DoMarkLand;
                        }
                        break;
                    case UAV_CP_Land:
                        drone->attitude_control(0x4b, 0, 0, -2, 0);
                        break;
                    case UAV_CP_GoHome:
                        if(Alex_WayPoint(drone,1,&home_point))
                        {
                            UAV_CP = UAV_CP_DoMarkLand;
                        }
                        break;
                    case UAV_CP_DoMarkAdjust:
                        Alex_VelControlLandMark(drone);
                        break;
                    case UAV_CP_DoMarkLand:
                        Alex_Land(drone);
                        //Alex_Land_SimuTest(drone);
                        break;
                    case UAV_CP_DoMarkFilterTest:
                        Alex_MarkFilterTest(drone);
                        break;
                    }

                    //drone->local_position_navigation_send_request(0,0,20);
                    //DJI_TakeOff(drone,20);
                    //Alex_VelControlWayPoint(drone, des_point);
                }
                else if(-4545 == dji_gear)
                {
                    //Alex_EulerControl(drone,des_point);
                    Alex_RemoterControl(drone);
                }
            }

            task_flag[0] = 0;
        }
        // Receive msg from GCS
        if(task_flag[TASK_REC])
        {
            //printf("This is flag rec loop.\n");
#ifdef DEBUG_GCS_LINK
            GCS_ReceiveLoop();
#endif // DEBUG_GCS_LINK
            task_flag[TASK_REC] = 0;
        }
        // Send Data to GCS
        if(task_flag[TASK_SEND_1HZ])
        {

            //printf("This is flag send loop.\n");
            //printf("Current time:%d\n",GCS_Get_time_ms());
#ifdef DEBUG_GCS_LINK
            cnt_send += 1;
            //GCS_SendGPS(1,lat_init + 0.00003*cnt_send,lon_init+0.00003*cnt_send,9.9+0.01*cnt_send);
            //GCS_SendImage(picname);
#endif
            task_flag[TASK_SEND_1HZ] = 0;

        }
        if(task_flag[TASK_SEND_5HZ])
        {
#ifdef DEBUG_GCS_LINK
            //GCS_SendGPS(2,visual_gps_lat,visual_gps_lon,dji_gps_alt);
            GCS_SendGPS(2,cf_gps_lat,cf_gps_lon,dji_gps_alt);
            GCS_SendGPS(1,dji_gps_lat,dji_gps_lon,dji_gps_alt);
            GCS_SendUAVState(uav_state);
            GCS_SendFlightMode(UAV_CP);
            GCS_SendLandMarkPos(filter_landmark_dx,filter_landmark_dy);
            unsigned int t=GCS_Get_time_ms();
            file<<t<<"    "<<endl;
            file<<"DJI GPS:"<<setiosflags(ios::fixed)<<setprecision(6)<<dji_gps_lat<<" "<<dji_gps_lon<<" "<<dji_gps_alt<<endl;
            file<<"Visual GPS:"<<setiosflags(ios::fixed)<<setprecision(6)<<visual_gps_lat<<" "<<visual_gps_lon<<endl;
            file<<"Filter GPS:"<<setiosflags(ios::fixed)<<setprecision(6)<<cf_gps_lat<<" "<<cf_gps_lon<<endl;
#endif
            task_flag[TASK_SEND_5HZ] = 0;
        }
        time_now = GCS_Get_time_ms();
        for(int i=0; i<TASK_COUNT; ++i)
        {
            if((time_now - task_time[i]) > (unsigned int)(1000/task_hz[i]))
            {
                task_flag[i] = 1;
                task_time[i] = time_now;
            }
        }
    }
#ifdef DEBUG_GCS_LINK
    GCS_EndLink();
#endif // DEBUG_GCS_LINK
    // --------------------------------------------------
    return 0;
}
// ========================================================================================
// ========================================================================================
float DJI_TakeOff(DJIDrone* drone,float des_alt)
{
    /*
    float cur_alt = drone->global_position.height;
    float delta_alt = des_alt - cur_alt;
    float kp = 0.2;
    float vel = 0;
    while(delta_alt < 0.2)
    {
        delta_alt = des_alt - cur_alt;
        vel = kp*delta_alt;
        drone->attitude_control(0x0a, 0, 0, vel, 0);
        cur_alt = drone->global_position.height;
    }
    */
    float cur_alt = cur_point.alt;
    float delta_alt = des_alt - cur_alt;
    if(fabs(delta_alt) > 2)
    {
        delta_alt = des_alt - cur_alt;
        drone->attitude_control(0x59, 0, 0, des_alt, 0);
    }
    return fabs(delta_alt);
}
/*
 * Used to update M100 flight data
 *
 */
void DJI_SDK_Loop(DJIDrone* drone)
{
    static unsigned int time_old = GCS_Get_time_ms();
    float roll  = atan2(2.0 * (drone->attitude_quaternion.q3 * drone->attitude_quaternion.q2 + drone->attitude_quaternion.q0 * drone->attitude_quaternion.q1) , 1.0 - 2.0 * (drone->attitude_quaternion.q1 * drone->attitude_quaternion.q1 + drone->attitude_quaternion.q2 * drone->attitude_quaternion.q2));
    float pitch = asin(2.0 * (drone->attitude_quaternion.q2 * drone->attitude_quaternion.q0 - drone->attitude_quaternion.q3 * drone->attitude_quaternion.q1));
    yaw   = atan2(2.0 * (drone->attitude_quaternion.q3 * drone->attitude_quaternion.q0 + drone->attitude_quaternion.q1 * drone->attitude_quaternion.q2) , - 1.0 + 2.0 * (drone->attitude_quaternion.q0 * drone->attitude_quaternion.q0 + drone->attitude_quaternion.q1 * drone->attitude_quaternion.q1));
//    cout<<"================>>>"<<endl;
    //cout<<"roll "<<roll<<"   pitch "<<pitch<<"   yaw "<<yaw<<endl;
    /*
    float q0 = drone->attitude_quaternion.q0;
    float q1 = drone->attitude_quaternion.q1;
    float q2 = drone->attitude_quaternion.q2;
    float q3 = drone->attitude_quaternion.q3;
    Rbe11 = q0*q0 + q1*q1 -q2*q2 - q3*q3;
    Rbe12 = 2*(q1*q2 - q0*q3);
    Rbe13 = 2*(q1*q3 + q0*q2);
    Rbe21 = 2*(q1*q2 + q0*q3);
    Rbe22 = q0*q0 - q1*q1 + q2*q2 - q3*q3;
    Rbe23 = 2*(q2*q3 - q0*q1);
    Rbe31 = 2*(q1*q3 - q0*q2);
    Rbe32 = 2*(q2*q3 + q0*q1);
    Rbe33 = q0*q0 - q1*q1 - q2*q2 + q3*q3;
    */


    dji_gps_lat=drone->global_position.latitude;
    dji_gps_lon = drone->global_position.longitude;
    dji_gps_alt =drone->global_position.height;
    dji_globalvelx = drone->velocity.vx;
    dji_globalvely = drone->velocity.vy;
    dji_globalvelz = drone->velocity.vz;
    /*
    if(!cf_flag_begin)
    {
        cf_flag_begin = true;
        cf_gps_lat = dji_gps_lat;
        cf_gps_lon = dji_gps_lon;
    }*/
    if(cf_flag_begin)
    {
        cf_gps_lat = cf_gps_lat + cf_ratio_lat*(GCS_Get_time_ms()-time_old)/1000*dji_globalvelx;
        cf_gps_lon = cf_gps_lon + cf_ratio_lon*(GCS_Get_time_ms()-time_old)/1000*dji_globalvely;
        time_old = GCS_Get_time_ms();
        navigation_file<<"Time: "<<time_old<<endl;
        //cout<<"Gps: "<<"lat-->"<<setiosflags(ios::fixed)<<setprecision(6)<<dji_gps_lat<<"lon-->"<<dji_gps_lon<<endl;
        //cout<<"Vis: "<<"lat-->"<<setiosflags(ios::fixed)<<setprecision(6)<<cf_gps_lat<<"lon-->"<<cf_gps_lon<<endl;
        navigation_file<<"Updating GPS position: lat-> "<<setiosflags(ios::fixed)<<setprecision(6)<<cf_gps_lat<<" lon->"<<cf_gps_lon<<endl;
        if(flag_visual_guidence)
        {
            cur_point.lat = cf_gps_lat;
            cur_point.lon = cf_gps_lon;
        }
        //file_test<<time_old<<setiosflags(ios::fixed)<<setprecision(6)<<dji_gps_lat<<"  "<<dji_gps_lon<<"  "<<cf_gps_lat<<"  "<<cf_gps_lon<<endl;
    }
    if(!flag_visual_guidence)
    {
        cur_point.lat = dji_gps_lat;
        cur_point.lon = dji_gps_lon;
    }
    cur_point.alt = dji_gps_alt;
    /*
    dji_bodyvelx = Rbe11*dji_globalvelx + Rbe21*dji_globalvely + Rbe31*dji_globalvelz;
    dji_bodyvely = Rbe12*dji_globalvelx + Rbe22*dji_globalvely + Rbe32*dji_globalvelz;
    dji_bodyvelz = Rbe13*dji_globalvelx + Rbe23*dji_globalvely + Rbe33*dji_globalvelz;
    */
    dji_bodyvelx = cos(yaw)*dji_globalvelx + sin(yaw)*dji_globalvely;
    dji_bodyvely = -sin(yaw)*dji_globalvelx + cos(yaw)*dji_globalvely;
    //cout<<"global: vx->"<<dji_globalvelx<<"  vy->"<<dji_globalvely<<endl;
    //cout<<"body:   vx->"<<dji_bodyvelx<<"  vy->"<<dji_bodyvely<<endl;
    dji_gear = drone->rc_channels.gear;
    //cout<<"dji lat: "<<dji_gps_lat<<" dji lon: "<<dji_gps_lon<<"  dji alt:"<<dji_gps_alt<<endl;
}
// confine the value to specified range make value belong to (low,high)
float ConfineRange(float value,float low,float high)
{
    //float res;
    //res = (((value<low)?low:value)>high)?high:value;
    float res = (value<low)?low:value;
    res = (res>high)?high:res;
    return res;
}
#define C_PI     3.14159
#define C_EARTH  6378137.0
/*
void Alex_EulerControl(DJIDrone* drone,WayPoint_t des_point)
{
    float d_lat,d_lon,delta_x,delta_y,ctl_x,ctl_y;
    float kp = 0.5;
    d_lat = des_point.lat - cur_point.lat;
    d_lon = des_point.lon - cur_point.lon;
    delta_x = (d_lat*C_PI/180)*C_EARTH;//6371000
    delta_y = (d_lon*C_PI/180)*C_EARTH*cos(des_point.lat*C_PI/180);
    cout<<"Delta: "<<delta_x<<"  "<<delta_y<<endl;
    if(fabs(delta_x )> 5 || fabs(delta_y) >5)
    {
        ctl_x = cos(yaw)*delta_x + sin(yaw)*delta_y;
        ctl_y = -sin(yaw)*delta_x + cos(yaw)*delta_y;

        ctl_x = ConfineRange(kp*ctl_x,-15,15);
        ctl_y = ConfineRange(kp*ctl_y,-15,15);
        cout<<"Drone Control:ctl_x "<<ctl_x<<" ctl_y "<<ctl_y<<endl;

        drone->attitude_control(Flight::HorizontalLogic::HORIZONTAL_VELOCITY |
                                Flight::VerticalLogic::VERTICAL_VELOCITY |
                                Flight::YawLogic::YAW_ANGLE |
                                Flight::HorizontalCoordinate::HORIZONTAL_BODY |
                                Flight::SmoothMode::SMOOTH_ENABLE, ctl_x, ctl_y, 0, 0);
    }
    else
    {
        uav_state = uav_state_reachedonewp;
    }
}
*/
//
double Distance(double lat1, double long1, double lat2, double long2)
{
    double a, b, R;
    R = 6378137; //µØÇò°ëŸ¶
    lat1 = lat1 * C_PI / 180.0;
    lat2 = lat2 * C_PI / 180.0;
    a = lat1 - lat2;
    b = (long1 - long2) * C_PI / 180.0;
    double d;
    double sa2, sb2;
    sa2 = sin(a / 2.0);
    sb2 = sin(b / 2.0);
    d = 2 * R * asin(sqrt(sa2 * sa2 + cos(lat1) * cos(lat2) * sb2 * sb2));
    return d;
}
float Alex_VelControlWayPoint(DJIDrone* drone, WayPoint_t des_point)
{
    static float max_vel = 3.0f;
    float d_lat,d_lon,delta_x,delta_y,ctl_x,ctl_y;
    float kp = 0.2;
    d_lat = (float)Distance(des_point.lat,cur_point.lon,cur_point.lat,cur_point.lon);
    d_lon = (float)Distance(cur_point.lat,des_point.lon,cur_point.lat,cur_point.lon);
    //cout<<setiosflags(ios::fixed)<<setprecision(6)<<"curLat: "<<cur_point.lat<<"  curLon: "<<cur_point.lon<<endl;
    //cout<<setiosflags(ios::fixed)<<setprecision(6)<<"desLat: "<<des_point.lat<<"  desLon: "<<des_point.lon<<endl;
    delta_x = d_lat;
    delta_y = d_lon;
    if((des_point.lat - cur_point.lat) < 0)
    {
        delta_x = -d_lat;
    }
    if((des_point.lon - cur_point.lon)<0)
    {
        delta_y = -d_lon;
    }
    file_test<<"  d_lat "<<d_lat<<"  d_lon "<<d_lon<<"  dx "<<delta_x<<"  dy "<<delta_y<<endl;
    float delta = sqrt(delta_x*delta_x + delta_y*delta_y);
    if(delta > 1)
    {
        ctl_x = ConfineRange(kp*delta_x,-max_vel,max_vel);
        ctl_y = ConfineRange(kp*delta_y,-max_vel,max_vel);
        //cout<<"--------->     ctl_x:"<<ctl_x<<"  ctl_y:"<<ctl_y<<endl;
        //file_test<<"--------->     ctl_x:"<<ctl_x<<"  ctl_y:"<<ctl_y<<endl;
        ctl_y = ctl_y*(d_lon/d_lat);
        //cout<<"Before--->     ctl_x:"<<ctl_x<<"  ctl_y:"<<ctl_y<<endl;
        //file_test<<"Before--->     ctl_x:"<<ctl_x<<"  ctl_y:"<<ctl_y<<endl;
        if(fabs(ctl_y)>max_vel)
        {
            ctl_y = ConfineRange(kp*delta_y,-max_vel,max_vel);
            ctl_x = ctl_x*(d_lat/d_lon);
            //cout<<"Ing---->    ctl_x:"<<ctl_x<<"  ctl_y:"<<ctl_y<<endl;
            //file_test<<"Ing---->    ctl_x:"<<ctl_x<<"  ctl_y:"<<ctl_y<<endl;
        }
        else
        {
            //cout<<"Error:  fabs(ctly) "<<fabs(ctl_y)<<endl;
            //file_test<<"Error:  fabs(ctly) "<<ctl_y<<endl;
        }
        //cout<<"After---->     ctl_x "<<ctl_x<<" ctl_y "<<ctl_y<<endl;
        //file_test<<"After---->     ctl_x "<<ctl_x<<" ctl_y "<<ctl_y<<endl;
        uav_state = uav_state_goingtowp;
        drone->attitude_control(0x49, ctl_x, ctl_y, 0, 0);
    }
    else
    {
        uav_state = uav_state_reachedonewp;
    }
    return delta;
}
bool Alex_WayPoint(DJIDrone* drone,int wp_num,WayPoint_t *wps)
{
    float delta = Alex_VelControlWayPoint(drone,wps[wp_n]);
    waypoint_nav<<"Current point index is:"<<wp_n<<" Delta is:"<<delta<<endl;
    if(delta<waypoint_range)
    {
        ++wp_n;
        printf("[Debug] Next point index is %d\n",wp_n);
        waypoint_nav<<"Next wp index is:"<<wp_n<<endl;
    }
    if(wp_n == wp_num)
    {
        printf("[Debug] Waypoint over\n");
        waypoint_nav<<"Waypoint over"<<wp_n<<endl;
        uav_state = uav_state_allwpsover;
        return true;
    }
    return false;
}
// ============================================================================================================================
// ============================================================================================================================
// ============================================================================================================================
float Alex_VelControlLandMark(DJIDrone* drone)
{
    static unsigned int time_old = GCS_Get_time_ms();
    float delta_x,delta_y,ctl_x,ctl_y;
    float delta = 0;
    float kp = 0.3;
    filter_landmark_dx -= (GCS_Get_time_ms() - time_old)/1000*dji_bodyvelx;
    filter_landmark_dy -= (GCS_Get_time_ms() - time_old)/1000*dji_bodyvely;
    time_old = GCS_Get_time_ms();

    delta_x = filter_landmark_dx;
    delta_y = filter_landmark_dy;
    delta = sqrt(delta_x*delta_x + delta_y*delta_y);
    if(delta>1)
    {
        ctl_x = ConfineRange(kp*delta_x,-1,1);
        ctl_y = ConfineRange(kp*delta_y,-1,1);
        drone->attitude_control(0x4b, ctl_x, ctl_y, 0, 0);
        //printf("[Debug] Into landmark adjust.\n");
        //mark_land_file<<"Land mark: "<<setiosflags(ios::fixed)<<setprecision(6)<<landmark_dx<<" "<<landmark_dy<<" "<<landmark_ratio<<endl;
    }
    else
    {
        mark_land_file<<"Land mark: Position adjusted well"<<endl;
    }
    return delta;
}
void Alex_MarkFilterTest(DJIDrone* drone)
{
    static unsigned int time_old = GCS_Get_time_ms();
    if(flag_begin_marktest)
    {
        filter_landmark_dx -= (GCS_Get_time_ms() - time_old)/1000*dji_bodyvelx;
        filter_landmark_dy -= (GCS_Get_time_ms() - time_old)/1000*dji_bodyvely;
        mark_file<<"updating: filter_dx->"<<filter_landmark_dx<<"  filter_dy->"<<filter_landmark_dy<<endl;
    }
    time_old = GCS_Get_time_ms();
}
// Process:
// land--->> at right height----->> loiter for 5 seconds ---->> if detect land mark then adjust positon
void Alex_Land(DJIDrone* drone)
{
    static int flagland   = 100;
    static float range = 5.0;
    static int flagmark   = 0;
    float delta = 0;
    static float average_dx = 0.0;
    static float average_dy = 0.0;
    // If you rebegin the land mission
    static bool flagloiter = false;
    static unsigned int loiterbegintime = 0;
    static int timeout_cnt = 0;
    if(RebeginFlag_MarkLand100)                 // land begin at 100m
    {
        RebeginFlag_MarkLand100 = false;
        flagland = 100;
        flagmark = 0;
        range = 20.0;
        flagloiter = false;
        mark_land_file<<"Step 1, Land will begin at 100m"<<endl;
    }
    if(RebeginFlag_MarkLand50)                 // land begin at 50m
    {
        RebeginFlag_MarkLand50 = false;
        flagland = 50;
        flagmark = 0;
        range = 3.0;
        flagloiter = false;
        mark_land_file<<"Step 1, Land will begin at 50m"<<endl;
    }
    // If the land mark has been detected, then begin the position adjusting
    if(flagmark != 0)
    {
        // begin fuse vel and pos
        delta = Alex_VelControlLandMark(drone);
        mark_land_file<<"At height:"<<dji_gps_alt<<"Current delta is:"<<delta<<endl;
        if(delta<range)
        {
            flagmark = 0;
            //
            switch(flagland)
            {
            case 100:
                flagland = 50;
                range = 3.0;
                break;
            case 50:
                range = 1.5;
                flagland = 20;
                break;
            case 20:
                flagland = -5;
                break;
            }
        }
        return;
    }
    // if not in specific altitude, just go down.
    double delta_height = (double)flagland - dji_gps_alt;
    if(fabs(delta_height) > 2)
    {
        double ctl_h = ConfineRange(delta_height,-1.5,1.5);
        drone->attitude_control(0x4b, 0, 0, ctl_h, 0);
        uav_state = UAV_state_landing;
    }
    // Now you are in the desired altitude, you need to detect the landmark
    else
    {
        drone->attitude_control(0x4b, 0, 0, 0, 0);
        // before land mark detect, you need loiter for a few seconds, at here is 5seconds.
        if(!flagloiter)
        {
            mark_land_file<<"Step 2, Begin horizon adjusting at "<<flagland<<endl;
            flagloiter = true;
            loiterbegintime = GCS_Get_time_ms();
            mark_land_file<<"---------------------------------->>>"<<endl;
            mark_land_file<<loiterbegintime<<"    "<<"Begin loiter at height:"<<flagland<<endl;
        }
        if(flagloiter && (GCS_Get_time_ms() - loiterbegintime) > 3000)
        {
            flagloiter = false;
            mark_land_file<<"---------------------------------->>>"<<endl;
            mark_land_file<<GCS_Get_time_ms()<<"    "<<"End loiter at height:"<<flagland<<endl;
            if(fabs(landmark_dx)>0.01 && fabs(landmark_dy)>0.01 && landmark_ratio > 0)
            {
                flagmark = 1;
                uav_state = UAV_state_detectedlandmark;
                filter_landmark_dx = landmark_dx*landmark_ratio;
                filter_landmark_dy = landmark_dy*landmark_ratio;
                mark_land_file<<"Step 3,Sucessed detect the land mark at height "<<flagland<<endl;
                mark_land_file<<"Initialized the position: dx-> "<<filter_landmark_dx<<"  dy->"<<filter_landmark_dy<<endl;
                timeout_cnt = 0;
            }
            else
            {
                ++timeout_cnt;
                uav_state = UAV_state_notdetectedlandmark;
                mark_land_file<<"Failed detect the land mark at height "<<flagland<<", have tried "<<timeout_cnt<<"times"<<endl;
                // If tried 5 times and still no mark, then continue land.
                if(timeout_cnt>5)
                {
                    timeout_cnt = 0;
                    flagmark = 1;
                    mark_land_file<<"Failed detect the land mark, Time out!"<<endl;
                }
            }
        }
    }
}
// loiter for a few second at specified height then land to  another height
void Alex_Land_SimuTest(DJIDrone* drone)
{
    static int flagland   = 100;
    static float range = 5.0;
    static int flagmark   = 0;
    float delta = 0;
    static float average_dx = 0.0;
    static float average_dy = 0.0;
    // If you rebegin the land mission
    static bool flagloiter = false;
    static unsigned int loiterbegintime = 0;
    if(RebeginFlag_MarkLand100)
    {
        RebeginFlag_MarkLand100 = false;
        flagland = 100;
        flagmark = 0;
    }
    if(flagmark != 0)
    {
        // begin fuse vel and pos

        //delta = Alex_VelControlLandMark(drone);
        //if(delta<range)
        //{
        flagmark = 0;
        //
        switch(flagland)
        {
        case 100:
            flagland = 50;
            range = 3.0;
            break;
        case 50:
            range = 1.0;
            flagland = 20;
            break;
        case 20:
            flagland = -5;
            break;
        }
        //}
        return;
    }
    // if not in specific altitude, just go down.
    if(fabs(dji_gps_alt-flagland) > 2)
    {
        drone->attitude_control(0x4b, 0, 0, -2, 0);
        uav_state = UAV_state_landing;
    }
    else
    {
        drone->attitude_control(0x4b, 0, 0, 0, 0);
        //sleep(1);
        if(!flagloiter)
        {
            flagloiter = true;
            loiterbegintime = GCS_Get_time_ms();
            mark_file<<loiterbegintime<<"    "<<"Begin loiter at height:"<<flagland<<endl;
        }
        if(flagloiter && (GCS_Get_time_ms() - loiterbegintime) > 5000)
        {
            flagloiter = false;
            mark_file<<GCS_Get_time_ms()<<"    "<<"End loiter at height:"<<flagland<<endl;
            //if(landmark_ratio > 0)
            //{
            flagmark = 1;
            uav_state = UAV_state_detectedlandmark;
            //}
            //else
            //{
            //   uav_state = UAV_state_notdetectedlandmark;
            //}
        }
    }

}
// ============================================================================================================================
// ============================================================================================================================
// ============================================================================================================================
void Alex_RemoterControl(DJIDrone* drone)
{
    float vx = (drone->rc_channels.pitch)/10000*5;
    float vy = (drone->rc_channels.roll)/10000*5;
    float vz = (drone->rc_channels.throttle)/10000*5;
    drone->attitude_control(0x4b, vx, vy, vz, 0);
    //printf("==========vx:%f,  vy:%f,  vz:%f\n",vx,vy,vz);
}

// ============================================================================================================================
// ============================================================================================================================
// ============================================================================================================================
















//drone->global_position_navigation_send_request(22.535, 113.95, 100);
/*
void update_offset()
{
    offset_x = target_x - current_x;
    offset_y = target_y - current_y;
}


FlightData data;
data.flag = 0x90;
data.x = offset_x;
data.y = offset_y;
data.z = target_z;
data.yaw = target_yaw;
flight->setFlight(&data);
*/


/*
void Test_SendImgGPS()
{
GCS_LinkServer();
GCS_SendIdentifier();
GCS_SendGPS(3,lat_init,lon_init,100.0f);
for(int i=1;i<11;i++)
{
    char picname[30];
    sprintf(picname,"./src/dji_ros/Onboard-SDK-ROS/dji_sdk_demo/pic_test/%d.jpg",i);
    GCS_SendImage(picname);
    GCS_SendGPS(2,lat_init + 0.0001*i,lon_init + 0.0001*i,100.0f);
    GCS_SendGPS(1,lat_init + 0.0001*i,lon_init + 0.0001*i,100.0f);

    printf("Afff\n");
    usleep(2e6);
}
GCS_EndLink();
}
*/




//static void Display_Main_Menu(void)
//{
//    printf("\r\n");
//    printf("----------- < Main menu > ----------\r\n\r\n");
//    printf("[a] Request to obtain control\n");
//    printf("[b] Release control\n");
//    printf("[c] Takeoff\n");
//    printf("[d] Landing\n");
//    printf("[e] Go home\n");
//    printf("[f] Gimbal control sample\n");
//    printf("[g] Attitude control sample\n");
//    printf("[h] Draw circle sample\n");
//    printf("[i] Draw square sample\n");
//    printf("[j] Take a picture\n");
//    printf("[k] Start video\n");
//    printf("[l] Stop video\n");
//    printf("[m] Local Navi Test\n");
//    printf("[n] GPS Navi Test\n");
//    printf("[o] Waypoint List Test\n");
//    printf("[p] Exit\n");
//    printf("\ninput a/b/c etc..then press enter key\r\n");
//    printf("\nuse `rostopic echo` to query drone status\r\n");
//    printf("----------------------------------------\r\n");
//    printf("input: ");
//}
//int main(int argc, char **argv)
//{




//    int main_operate_code = 0;
//    int temp32;
//    bool valid_flag = false;
////    bool err_flag = false;
//    ros::init(argc, argv, "sdk_client");
//    ROS_INFO("sdk_service_client_test");
//    ros::NodeHandle nh;
//    DJIDrone* drone = new DJIDrone(nh);
//
//    dji_sdk::WaypointList newWaypointList;
//    dji_sdk::Waypoint waypoint0;
//    dji_sdk::Waypoint waypoint1;
//    dji_sdk::Waypoint waypoint2;
//    dji_sdk::Waypoint waypoint3;
//    dji_sdk::Waypoint waypoint4;


////    Display_Main_Menu();
//    long count=0;
//    ofstream file ("/home/ubuntu/Documents/fly_data/data.txt");
//    time_t timep;
//    while(1)
//    {
//        sleep(1);
////            float roll  = atan2(2.0 * (drone->attitude_quaternion.q3 * drone->attitude_quaternion.q2 + drone->attitude_quaternion.q0 * drone->attitude_quaternion.q1) , 1.0 - 2.0 * (drone->attitude_quaternion.q1 * drone->attitude_quaternion.q1 + drone->attitude_quaternion.q2 * drone->attitude_quaternion.q2));
////        float pitch = asin(2.0 * (drone->attitude_quaternion.q2 * drone->attitude_quaternion.q0 - drone->attitude_quaternion.q3 * drone->attitude_quaternion.q1));
////        float yaw   = atan2(2.0 * (drone->attitude_quaternion.q3 * drone->attitude_quaternion.q0 + drone->attitude_quaternion.q1 * drone->attitude_quaternion.q2) , - 1.0 + 2.0 * (drone->attitude_quaternion.q0 * drone->attitude_quaternion.q0 + drone->attitude_quaternion.q1 * drone->attitude_quaternion.q1));
////        cout<<"global_position: "<<endl<<drone->global_position<<endl;
//
//        if (file.is_open())
//        {
//            cout<<"status: "<<drone->flight_status<<endl;
//            if(drone->flight_status!=1&&drone->flight_status!=5)
//            {
//                time(&timep);
//                file<<"time: "<<asctime(gmtime(&timep))<<endl;
//                cout<<"time: "<<drone->gimbal<<endl;
////            file<<"attitude_quaternion: "<<endl<<drone->attitude_quaternion<<endl;
////            file<<"roll: "<<endl<<roll<<endl;
////            file<<"pitch: "<<endl<<pitch<<endl;
////            file<<"yaw: "<<endl<<yaw<<endl;
//                file<<setiosflags(ios::fixed)<<setprecision(6)<<"gimbal: "<<endl<<drone->gimbal<<endl;
////            file<<"compass: "<<endl<<drone->compass<<endl;
////            file<<"velocity: "<<endl<<drone->velocity<<endl;
//                file<<setiosflags(ios::fixed)<<setprecision(6)<<"global_position: "<<endl<<drone->global_position<<endl;
//            }
//        }
//        ros::spinOnce();
//        sleep(1);
////        temp32 = getchar();
////        if(temp32 != 10)
////        {
////            if(temp32 >= 'a' && temp32 <= 'p' && valid_flag == false)
////            {
////                main_operate_code = temp32;
////                valid_flag = true;
////            }
////            else
////            {
////                err_flag = true;
////            }
////            continue;
////        }
////        else
////        {
////            if(err_flag == true)
////            {
////                printf("input: ERROR\n");
////                Display_Main_Menu();
////                err_flag = valid_flag = false;
////                continue;
////            }
////        }
////        switch(main_operate_code)
////        {
////            case 'a':
////                /* request control ability*/
////                drone->request_sdk_permission_control();
////                break;
////            case 'b':
////                /* release control ability*/
////                drone->release_sdk_permission_control();
////                break;
////            case 'c':
////                /* take off */
////                drone->takeoff();
////                break;
////            case 'd':
////                /* landing*/
////                drone->landing();
////                break;
////            case 'e':
////                /* go home*/
////                drone->gohome();
////                break;
////            case 'f':
////                /*gimbal test*/
////
////                drone->gimbal_angle_control(0, 0, 1800, 20);
////                sleep(2);
////                drone->gimbal_angle_control(0, 0, -1800, 20);
////                sleep(2);
////                drone->gimbal_angle_control(300, 0, 0, 20);
////                sleep(2);
////                drone->gimbal_angle_control(-300, 0, 0, 20);
////                sleep(2);
////                drone->gimbal_angle_control(0, 300, 0, 20);
////                sleep(2);
////                drone->gimbal_angle_control(0, -300, 0, 20);
////                sleep(2);
////                drone->gimbal_speed_control(100, 0, 0);
////                sleep(2);
////                drone->gimbal_speed_control(-100, 0, 0);
////                sleep(2);
////                drone->gimbal_speed_control(0, 0, 200);
////                sleep(2);
////                drone->gimbal_speed_control(0, 0, -200);
////                sleep(2);
////                drone->gimbal_speed_control(0, 200, 0);
////                sleep(2);
////                drone->gimbal_speed_control(0, -200, 0);
////                sleep(2);
////                drone->gimbal_angle_control(0, 0, 0, 20);
////                break;
////
////            case 'g':
////                /* attitude control sample*/
////                drone->takeoff();
////                sleep(8);
////
////
////                for(int i = 0; i < 100; i ++)
////                {
////                    if(i < 90)
////                        drone->attitude_control(0x40, 0, 2, 0, 0);
////                    else
////                        drone->attitude_control(0x40, 0, 0, 0, 0);
////                    usleep(20000);
////                }
////                sleep(1);
////
////                for(int i = 0; i < 200; i ++)
////                {
////                    if(i < 180)
////                        drone->attitude_control(0x40, 2, 0, 0, 0);
////                    else
////                        drone->attitude_control(0x40, 0, 0, 0, 0);
////                    usleep(20000);
////                }
////                sleep(1);
////
////                for(int i = 0; i < 200; i ++)
////                {
////                    if(i < 180)
////                        drone->attitude_control(0x40, -2, 0, 0, 0);
////                    else
////                        drone->attitude_control(0x40, 0, 0, 0, 0);
////                    usleep(20000);
////                }
////                sleep(1);
////
////                for(int i = 0; i < 200; i ++)
////                {
////                    if(i < 180)
////                        drone->attitude_control(0x40, 0, 2, 0, 0);
////                    else
////                        drone->attitude_control(0x40, 0, 0, 0, 0);
////                    usleep(20000);
////                }
////                sleep(1);
////
////                for(int i = 0; i < 200; i ++)
////                {
////                    if(i < 180)
////                        drone->attitude_control(0x40, 0, -2, 0, 0);
////                    else
////                        drone->attitude_control(0x40, 0, 0, 0, 0);
////                    usleep(20000);
////                }
////                sleep(1);
////
////                for(int i = 0; i < 200; i ++)
////                {
////                    if(i < 180)
////                        drone->attitude_control(0x40, 0, 0, 0.5, 0);
////                    else
////                        drone->attitude_control(0x40, 0, 0, 0, 0);
////                    usleep(20000);
////                }
////                sleep(1);
////
////                for(int i = 0; i < 200; i ++)
////                {
////                    if(i < 180)
////                        drone->attitude_control(0x40, 0, 0, -0.5, 0);
////                    else
////                        drone->attitude_control(0x40, 0, 0, 0, 0);
////                    usleep(20000);
////                }
////                sleep(1);
////
////                for(int i = 0; i < 200; i ++)
////                {
////                    if(i < 180)
////                        drone->attitude_control(0xA, 0, 0, 0, 90);
////                    else
////                        drone->attitude_control(0xA, 0, 0, 0, 0);
////                    usleep(20000);
////                }
////                sleep(1);
////
////                for(int i = 0; i < 200; i ++)
////                {
////                    if(i < 180)
////                        drone->attitude_control(0xA, 0, 0, 0, -90);
////                    else
////                        drone->attitude_control(0xA, 0, 0, 0, 0);
////                    usleep(20000);
////                }
////                sleep(1);
////
////                drone->landing();
////
////                break;
////
////            case 'h':
////                /*draw circle sample*/
////                static float time = 0;
////                static float R = 2;
////                static float V = 2;
////                static float vx;
////                static float vy;
////                /* start to draw circle */
////                for(int i = 0; i < 300; i ++)
////                {
////                    vx = V * sin((V/R)*time/50.0f);
////                    vy = V * cos((V/R)*time/50.0f);
////
////                    drone->attitude_control(HORIZ_POS|VERT_VEL|YAW_ANG|HORIZ_BODY|YAW_BODY, vx, vy, 0, 0);
////                    usleep(20000);
////                    time++;
////                }
////                break;
////
////            case 'i':
////                /*draw square sample*/
////                for(int i = 0;i < 60;i++)
////                {
////                    drone->attitude_control(HORIZ_POS|VERT_VEL|YAW_ANG|HORIZ_BODY|YAW_BODY, 3, 3, 0, 0);
////                    usleep(20000);
////                }
////                for(int i = 0;i < 60;i++)
////                {
////                    drone->attitude_control(HORIZ_POS|VERT_VEL|YAW_ANG|HORIZ_BODY|YAW_BODY, -3, 3, 0, 0);
////                    usleep(20000);
////                }
////                for(int i = 0;i < 60;i++)
////                {
////                    drone->attitude_control(HORIZ_POS|VERT_VEL|YAW_ANG|HORIZ_BODY|YAW_BODY, -3, -3, 0, 0);
////                    usleep(20000);
////                }
////                for(int i = 0;i < 60;i++)
////                {
////                    drone->attitude_control(HORIZ_POS|VERT_VEL|YAW_ANG|HORIZ_BODY|YAW_BODY, 3, -3, 0, 0);
////                    usleep(20000);
////                }
////                break;
////            case 'j':
////                /*take a picture*/
////                drone->take_picture();
////                break;
////            case 'k':
////                /*start video*/
////                drone->start_video();
////                break;
////            case 'l':
////                /*stop video*/
////                drone->stop_video();
////                break;
////            case 'm':
////                /* Local Navi Test */
////                drone->local_position_navigation_send_request(-100, -100, 100);
////                break;
////            case 'n':
////                /* GPS Navi Test */
////                drone->global_position_navigation_send_request(22.535, 113.95, 100);
////                break;
////            case 'o':
////                /* Waypoint List Navi Test */
////                {
////                    waypoint0.latitude = 22.535;
////                    waypoint0.longitude = 113.95;
////                    waypoint0.altitude = 100;
////                    waypoint0.staytime = 5;
////                    waypoint0.heading = 0;
////                }
////                newWaypointList.waypoint_list.push_back(waypoint0);
////
////                {
////                    waypoint1.latitude = 22.535;
////                    waypoint1.longitude = 113.96;
////                    waypoint1.altitude = 100;
////                    waypoint1.staytime = 0;
////                    waypoint1.heading = 90;
////                }
////                newWaypointList.waypoint_list.push_back(waypoint1);
////
////                {
////                    waypoint2.latitude = 22.545;
////                    waypoint2.longitude = 113.96;
////                    waypoint2.altitude = 100;
////                    waypoint2.staytime = 4;
////                    waypoint2.heading = -90;
////                }
////                newWaypointList.waypoint_list.push_back(waypoint2);
////
////                {
////                    waypoint3.latitude = 22.545;
////                    waypoint3.longitude = 113.96;
////                    waypoint3.altitude = 10;
////                    waypoint3.staytime = 2;
////                    waypoint3.heading = 180;
////                }
////                newWaypointList.waypoint_list.push_back(waypoint3);
////
////                {
////                    waypoint4.latitude = 22.525;
////                    waypoint4.longitude = 113.93;
////                    waypoint4.altitude = 50;
////                    waypoint4.staytime = 0;
////                    waypoint4.heading = -180;
////                }
////                newWaypointList.waypoint_list.push_back(waypoint4);
////
////                drone->waypoint_navigation_send_request(newWaypointList);
////                break;
////            case 'p':
////                return 0;
////            default:
////                cout<<"cout info"<<drone->attitude_quaternion;
////                break;
////        }
////        main_operate_code = -1;
////        err_flag = valid_flag = false;
////        Display_Main_Menu();
//    }
//    file.close();
//    return 0;
//}


